@echo off
chcp 65001 >nul
title BodegaViva - Cloudflare Tunnel
color 0B

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                                                              ║
echo  ║        BodegaViva - Publicar con Cloudflare Tunnel           ║
echo  ║        (URL FIJA, gratis, sin cambiar al reiniciar)          ║
echo  ║                                                              ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.

:: Verificar XAMPP
tasklist /FI "IMAGENAME eq httpd.exe" 2>NUL | find /I "httpd.exe" >NUL
if %ERRORLEVEL% NEQ 0 (
    echo  ⚠️  Apache no está corriendo. Inicia XAMPP primero.
    pause
    exit /b 1
)

:: Verificar cloudflared
echo [1/4] Verificando cloudflared...
where cloudflared >NUL 2>NUL
if %ERRORLEVEL% NEQ 0 (
    if not exist "cloudflared.exe" (
        echo.
        echo  ⚠️  cloudflared no está instalado.
        echo.
        echo  Para instalar:
        echo  1. Ve a https://github.com/cloudflare/cloudflared/releases/latest
        echo  2. Descarga cloudflared-windows-amd64.exe
        echo  3. Renómbralo a cloudflared.exe y ponlo en esta carpeta
        echo.
        pause
        start https://github.com/cloudflare/cloudflared/releases/latest
        exit /b 1
    )
    set "CF_PATH=cloudflared.exe"
) else (
    set "CF_PATH=cloudflared"
)
echo    ✓ cloudflared encontrado.

:: Iniciar túnel rápido (sin necesidad de cuenta)
echo.
echo [2/4] Iniciando túnel público...
echo.
echo  ══════════════════════════════════════════════════════════
echo  NOTA: La URL se generará automáticamente y se mostrará aquí.
echo  A diferencia de ngrok, esta URL es más estable.
echo  ══════════════════════════════════════════════════════════
echo.

:: Iniciar cloudflared y capturar la URL
%CF_PATH% tunnel --url http://localhost:80 2>&1 | findstr /C:"trycloudflare.com" /C:"https://"
pause
