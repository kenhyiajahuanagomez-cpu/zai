# ZAI - Tienda de Abarrotes 🛒🇵🇪

Proyecto completo de tienda online de abarrotes inspirada en las bodegas peruanas, desarrollado con **HTML5, CSS3, JavaScript, PHP y MySQL**, listo para ejecutarse en **XAMPP**.

> Eslogan: *"Todo lo que necesitas, cerca de ti"*

---

## 📦 Características

### Tienda pública
- **Página de Inicio** con hero animado, categorías, productos destacados, ofertas y más vendidos
- **Tienda** completa con filtros por categoría, rango de precio y ordenamiento
- **5 categorías** con páginas independientes (Alimentos, Lácteos, Bebidas, Golosinas, Limpieza)
- **Ofertas** especiales con combos y countdown timer
- **Carrito de compras** funcional (AJAX, agregar/eliminar/actualizar cantidades)
- **Checkout** con datos del cliente, dirección, métodos de pago y confirmación por WhatsApp
- **Página Nosotros** con historia, misión, visión y valores
- **Contacto** con formulario, mapa y datos de la tienda

### Panel administrativo
- **Dashboard** con estadísticas, gráficos interactivos (Chart.js), accesos rápidos
- **Gestión de productos**: crear, editar, eliminar, marcar destacado/oferta/más vendido
- **Gestión de categorías** con modal crear/editar
- **Inventario** con alertas de stock bajo y productos agotados
- **Gestión de pedidos** con cambio de estado e integración WhatsApp
- **Gestión de clientes** con historial de compras
- **Ventas** con gráficos por método de pago
- **Reportes** con top productos, evolución mensual y distribución por categoría

### Diseño
- Identidad visual propia (verde oscuro, verde claro, blanco, amarillo)
- Animaciones suaves (scroll reveal, hover, transiciones)
- 100% responsive (desktop, tablet, celular)
- Tipografía moderna (Poppins + Quicksand)
- Iconos Font Awesome 6
- Gráficos Chart.js

---

## 🚀 Instalación en XAMPP

### Paso 1: Copiar el proyecto
Copia la carpeta `zai_tienda` completa a:
```
C:\xampp\htdocs\zai_tienda
```
(En Windows) o `/opt/lampp/htdocs/zai_tienda` (Linux) o `/Applications/XAMPP/htdocs/zai_tienda` (Mac).

### Paso 2: Iniciar XAMPP
1. Abre el **Panel de Control de XAMPP**
2. Inicia los servicios **Apache** y **MySQL** (deben quedar en verde)

### Paso 3: Crear la base de datos
1. Abre tu navegador y ve a: **http://localhost/phpmyadmin**
2. Haz clic en **Importar** (pestaña superior)
3. Selecciona el archivo `zai_tienda/config/zai_tienda.sql`
4. Haz clic en **Continuar** o **Importar**

Esto creará la base de datos `zai_tienda` con todas las tablas y datos de ejemplo.

### Paso 4: Verificar credenciales
Abre `zai_tienda/config/config.php` y verifica:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');      // usuario por defecto de XAMPP
define('DB_PASS', '');          // vacío por defecto en XAMPP
define('DB_NAME', 'zai_tienda');
```

### Paso 5: ¡Listo!
Abre en tu navegador:
```
http://localhost/zai_tienda/index.php
```

---

## 🔐 Acceso al Panel Administrativo

**URL:** `http://localhost/zai_tienda/admin/index.php`

**Credenciales de prueba:**
- 📧 Email: `admin@zai.pe`
- 🔑 Password: `admin123`

---

## 📁 Estructura del proyecto

```
zai_tienda/
├── index.php                 # Página de Inicio
├── config/
│   ├── config.php            # Configuración general
│   ├── db.php                # Conexión MySQLi (clase Database)
│   └── zai_tienda.sql        # Script de la base de datos
├── includes/
│   ├── header.php            # Header + navbar del sitio
│   ├── footer.php            # Footer + scripts
│   ├── header_admin.php      # Header del panel admin
│   ├── footer_admin.php      # Footer del panel admin
│   ├── functions.php         # Funciones auxiliares
│   └── _producto_card.php    # Partial reutilizable
├── css/
│   ├── style.css             # Estilos principales
│   ├── tienda.css            # Estilos tienda, categoría, ofertas, nosotros, contacto
│   ├── carrito.css           # Estilos carrito y checkout
│   ├── admin.css             # Estilos panel administrativo
│   └── responsive.css        # Media queries
├── js/
│   ├── main.js               # JS principal (navbar, toasts, animaciones)
│   ├── cart.js               # Carrito AJAX
│   ├── tienda.js             # Filtros y ordenamiento
│   └── admin.js              # JS del panel admin
├── img/                      # Imágenes subidas (se crea automáticamente)
├── pages/                    # Páginas internas
│   ├── tienda.php
│   ├── categoria.php
│   ├── ofertas.php
│   ├── carrito.php
│   ├── checkout.php
│   ├── nosotros.php
│   └── contacto.php
└── admin/                    # Panel administrativo
    ├── index.php             # Login
    ├── logout.php
    ├── dashboard.php         # Estadísticas y gráficos
    ├── productos.php
    ├── producto_form.php
    ├── categorias.php
    ├── inventario.php
    ├── pedidos.php
    ├── pedido_detalle.php
    ├── clientes.php
    ├── ventas.php
    └── reportes.php
```

---

## 🛠️ Tecnologías utilizadas

| Tecnología | Uso |
|---|---|
| HTML5 | Estructura semántica |
| CSS3 | Estilos, animaciones, responsive (Grid + Flexbox) |
| JavaScript (Vanilla) | Interactividad, AJAX, animaciones |
| PHP 7.4+ | Backend, lógica de servidor |
| MySQL / MariaDB | Base de datos relacional |
| phpMyAdmin | Administración de la BD |
| Chart.js | Gráficos del dashboard |
| Font Awesome 6 | Iconos |
| Google Fonts | Tipografía Poppins + Quicksand |

---

## 🗄️ Base de datos

### Tablas principales:
- **usuarios**: administradores del sistema
- **clientes**: datos de clientes que realizan pedidos
- **categorias**: 5 categorías de productos
- **productos**: ~40 productos con imágenes, precios, stock, etc.
- **pedidos**: pedidos realizados con estado y método de pago
- **detalle_pedidos**: items de cada pedido
- **ventas**: registro histórico de ventas para reportes
- **vista_productos_completos**: vista SQL para consultas rápidas

### Características de seguridad:
- ✅ Consultas preparadas (mysqli prepared statements) en toda la app
- ✅ Sanitización de inputs con `htmlspecialchars()` y `real_escape_string()`
- ✅ Tokens CSRF disponibles para formularios
- ✅ Contraseñas hasheadas con `password_hash()` (bcrypt)
- ✅ Validación de datos en el backend y frontend

---

## 📞 Configuración de WhatsApp

Para cambiar el número de WhatsApp, edita `config/config.php`:
```php
define('WHATSAPP_NUMBER', '51987654321'); // 51 + número (Perú)
```

El sistema generará enlaces automáticos `https://wa.me/...` para:
- Botón flotante de WhatsApp
- Confirmación de pedidos
- Contacto desde el panel admin con clientes

---

## ✨ Funcionalidades destacadas

### Carrito (AJAX)
- Agregar productos sin recargar la página
- Actualizar cantidades con botones +/−
- Eliminar productos con animación
- Calcular subtotales y total en tiempo real
- Contador animado en el icono del carrito

### Animaciones
- Reveal on scroll (Intersection Observer)
- Contadores animados (dashboard stats)
- Hover effects en tarjetas
- Toast notifications al agregar productos
- Countdown timer en ofertas
- Carrusel de imágenes suave

### Dashboard
- 4 tarjetas de estadísticas con contadores animados
- Gráfico de línea de ventas (7 días)
- Gráfico doughnut de productos por categoría
- Top 5 productos más vendidos
- Últimos pedidos y alertas de stock bajo
- Accesos rápidos a módulos

---

## 🐛 Solución de problemas

### "Error de conexión a la base de datos"
- Verifica que **MySQL** esté corriendo en XAMPP
- Verifica que hayas importado `zai_tienda.sql` desde phpMyAdmin
- Revisa las credenciales en `config/config.php`

### "Las imágenes no cargan"
- Las imágenes de productos se cargan desde Unsplash (requieren internet)
- Si no tienes internet, edítalas en el panel admin o en la BD

### "No puedo acceder al admin"
- URL correcta: `http://localhost/zai_tienda/admin/index.php`
- Email: `admin@zai.pe` · Password: `admin123`
- Si olvidas la contraseña, re-importa el SQL o genera un hash nuevo con PHP

### "La página se ve sin estilos"
- Verifica que la carpeta `css/` esté junto a `index.php`
- Verifica `SITE_URL` en `config/config.php` (debe ser `http://localhost/zai_tienda`)

---

## 📝 Próximas mejoras (roadmap)

- [ ] Sistema de registro/login para clientes
- [ ] Pasarela de pago real (Culqi, Mercado Pago)
- [ ] Cupones de descuento funcionales
- [ ] Lista de deseos (favoritos persistentes)
- [ ] Notificaciones push
- [ ] App móvil (PWA)
- [ ] Multi-sucursal
- [ ] Sistema de reseñas y calificaciones

---

## 👨‍💻 Información del proyecto

**ZAI - Tienda de Abarrotes**  
Proyecto educativo/demostrativo de e-commerce para bodegas peruanas.

Desarrollado con ❤️ usando PHP, MySQL, HTML5, CSS3 y JavaScript vanilla.

---

¿Dudas o sugerencias? ¡Revisa los archivos de configuración o edita lo que necesites! 🚀
