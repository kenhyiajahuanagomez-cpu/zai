<?php
/**
 * ZAI - Página de Categoría individual
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
if (!$id) redirigir(SITE_URL . '/pages/tienda.php');

$categoria = $db->fetchOne("SELECT * FROM categorias WHERE id = ? AND estado = 1", ['i', $id]);
if (!$categoria) {
    flash('error', 'La categoría no existe.');
    redirigir(SITE_URL . '/pages/tienda.php');
}

$productos = obtenerProductosPorCategoria($id);
$categorias = obtenerCategorias();

$pagina_activa = 'categorias';
$titulo = $categoria['nombre'];
$css_extra = ['tienda.css'];
$js_extra = ['cart.js', 'tienda.js'];

include __DIR__ . '/../includes/header.php';
?>
<script>var SITE_URL_JS = '<?= SITE_URL ?>';</script>

<!-- CATEGORIA HERO -->
<section class="categoria-hero">
    <div class="container">
        <nav class="breadcrumb" style="padding:0; border:none; margin-bottom:14px;">
            <ul>
                <li><a href="<?= SITE_URL ?>/index.php">Inicio</a></li>
                <li><a href="<?= SITE_URL ?>/pages/tienda.php">Tienda</a></li>
                <li><?= htmlspecialchars($categoria['nombre']) ?></li>
            </ul>
        </nav>
        <div class="categoria-hero-inner">
            <div class="categoria-hero-img">
                <img src="<?= normalizarImagen($categoria['imagen']) ?>" alt="<?= htmlspecialchars($categoria['nombre']) ?>"
                     onerror="this.src='https://via.placeholder.com/200x200/0E5A3C/FFFFFF?text=<?= urlencode($categoria['nombre']) ?>'">
            </div>
            <div class="categoria-hero-info">
                <h1><i class="fa-solid <?= htmlspecialchars($categoria['icono'] ?: 'fa-tag') ?>"></i> <?= htmlspecialchars($categoria['nombre']) ?></h1>
                <p><?= htmlspecialchars($categoria['descripcion']) ?></p>
            </div>
        </div>
    </div>
</section>

<!-- PRODUCTOS DE LA CATEGORÍA -->
<section class="container" style="padding:40px 0;">
    <div class="tienda-header">
        <div class="tienda-resultados">
            <strong><?= count($productos) ?></strong> productos en esta categoría
        </div>
        <div class="tienda-controls">
            <label>Ordenar por:</label>
            <select id="sortSelect">
                <option value="popular">Más populares</option>
                <option value="precio-asc">Precio: menor a mayor</option>
                <option value="precio-desc">Precio: mayor a menor</option>
                <option value="nombre">Nombre A-Z</option>
            </select>
        </div>
    </div>

    <?php if (empty($productos)): ?>
        <div class="empty-state">
            <i class="fa-solid fa-box-open"></i>
            <h3>Próximamente más productos</h3>
            <p>Estamos trabajando para traerte más productos en esta categoría.</p>
            <a href="<?= SITE_URL ?>/pages/tienda.php" class="btn btn-primary">
                <i class="fa-solid fa-arrow-left"></i> Volver a la tienda
            </a>
        </div>
    <?php else: ?>
        <div class="productos-grid">
            <?php foreach ($productos as $p): ?>
                <?php include __DIR__ . '/../includes/_producto_card.php'; ?>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Otras categorías -->
    <div style="margin-top:60px;">
        <h2 style="text-align:center; font-size:24px; color:var(--verde-oscuro); margin-bottom:30px;">Explora otras categorías</h2>
        <div class="categorias-grid">
            <?php foreach ($categorias as $c): ?>
                <?php if ($c['id'] == $id) continue; ?>
                <a href="<?= SITE_URL ?>/pages/categoria.php?id=<?= $c['id'] ?>" class="categoria-card reveal">
                    <div class="categoria-icon"><i class="fa-solid <?= htmlspecialchars($c['icono'] ?: 'fa-tag') ?>"></i></div>
                    <h3><?= htmlspecialchars($c['nombre']) ?></h3>
                    <p><?= htmlspecialchars(acortar($c['descripcion'], 60)) ?></p>
                </a>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
