<?php
/**
 * ZAI - Checkout / Finalizar Compra
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$carrito = $_SESSION['carrito'] ?? [];
$total = carritoTotal();

// Si no hay carrito, redirigir
if (empty($carrito)) {
    flash('info', 'Tu carrito está vacío. Agrega productos antes de finalizar la compra.');
    redirigir(SITE_URL . '/pages/tienda.php');
}

$pagina_activa = 'carrito';
$titulo = 'Finalizar Compra';
$css_extra = ['carrito.css'];

$errores = [];
$enviado = false;
$pedido_id = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = limpiar($_POST['nombre'] ?? '');
    $celular = limpiar($_POST['celular'] ?? '');
    $direccion = limpiar($_POST['direccion'] ?? '');
    $referencia = limpiar($_POST['referencia'] ?? '');
    $metodo = $_POST['metodo_pago'] ?? 'efectivo';
    $observaciones = limpiar($_POST['observaciones'] ?? '');

    if (empty($nombre)) $errores[] = 'El nombre es obligatorio';
    if (empty($celular)) $errores[] = 'El celular es obligatorio';
    if (empty($direccion)) $errores[] = 'La dirección es obligatoria';
    if (!in_array($metodo, ['efectivo', 'yape', 'plin', 'transferencia'])) $metodo = 'efectivo';

    if (empty($errores)) {
        // Insertar cliente (si no existe, lo creamos)
        $cliente_existente = $db->fetchOne("SELECT id FROM clientes WHERE celular = ?", ['s', $celular]);
        $cliente_id = null;
        if ($cliente_existente) {
            $cliente_id = $cliente_existente['id'];
        } else {
            $cliente_id = $db->insert(
                "INSERT INTO clientes (nombre, celular, direccion, referencia) VALUES (?, ?, ?, ?)",
                ['ssss', $nombre, $celular, $direccion, $referencia]
            );
        }

        // Insertar pedido
        $pedido_id = $db->insert(
            "INSERT INTO pedidos (cliente_id, nombre_cliente, celular, direccion, referencia, metodo_pago, total, estado) 
             VALUES (?, ?, ?, ?, ?, ?, ?, 'pendiente')",
            ['issssd', $cliente_id, $nombre, $celular, $direccion, $referencia, $metodo, $total]
        );

        // Insertar detalle_pedido
        foreach ($carrito as $item) {
            $subtotal = $item['precio'] * $item['cantidad'];
            // Si el item es un producto real (id numérico)
            if (is_numeric($item['id'])) {
                $db->insert(
                    "INSERT INTO detalle_pedidos (pedido_id, producto_id, nombre_producto, cantidad, precio_unitario, subtotal) 
                     VALUES (?, ?, ?, ?, ?, ?)",
                    ['iisidd', $pedido_id, (int)$item['id'], $item['nombre'], $item['cantidad'], $item['precio'], $subtotal]
                );
                // Actualizar stock y vendidos
                $db->execute(
                    "UPDATE productos SET stock = stock - ?, vendidos = vendidos + ? WHERE id = ?",
                    ['iii', $item['cantidad'], $item['cantidad'], (int)$item['id']]
                );
            } else {
                // Para combos, registramos sin producto_id (usamos 0 o un placeholder)
                $db->insert(
                    "INSERT INTO detalle_pedidos (pedido_id, producto_id, nombre_producto, cantidad, precio_unitario, subtotal) 
                     VALUES (?, 0, ?, ?, ?, ?)",
                    ['isidd', $pedido_id, $item['nombre'], $item['cantidad'], $item['precio'], $subtotal]
                );
            }
        }

        // Registrar venta
        $db->insert(
            "INSERT INTO ventas (pedido_id, fecha_venta, monto, metodo_pago) VALUES (?, CURDATE(), ?, ?)",
            ['ids', $pedido_id, $total, $metodo]
        );

        // Limpiar carrito
        unset($_SESSION['carrito']);
        $enviado = true;
    }
}

include __DIR__ . '/../includes/header.php';
?>
<script>var SITE_URL_JS = '<?= SITE_URL ?>';</script>

<!-- BREADCRUMB -->
<nav class="breadcrumb">
    <div class="container">
        <ul>
            <li><a href="<?= SITE_URL ?>/index.php">Inicio</a></li>
            <li><a href="<?= SITE_URL ?>/pages/carrito.php">Carrito</a></li>
            <li>Checkout</li>
        </ul>
    </div>
</nav>

<section class="checkout-page">
    <div class="container">
        <?php if ($enviado && $pedido_id): ?>
            <!-- CONFIRMACIÓN -->
            <div class="confirmacion-pedido">
                <div class="confirmacion-icon">
                    <i class="fa-solid fa-check"></i>
                </div>
                <h1>¡Pedido confirmado!</h1>
                <p>Gracias <strong><?= htmlspecialchars($nombre) ?></strong>, hemos recibido tu pedido. Te contactaremos por WhatsApp para coordinar la entrega.</p>

                <div class="pedido-info">
                    <div class="pedido-info-row">
                        <span>N° de pedido</span>
                        <span>#<?= SITE_PREFIX ?>-<?= str_pad($pedido_id, 5, '0', STR_PAD_LEFT) ?></span>
                    </div>
                    <div class="pedido-info-row">
                        <span>Cliente</span>
                        <span><?= htmlspecialchars($nombre) ?></span>
                    </div>
                    <div class="pedido-info-row">
                        <span>Celular</span>
                        <span><?= htmlspecialchars($celular) ?></span>
                    </div>
                    <div class="pedido-info-row">
                        <span>Dirección</span>
                        <span><?= htmlspecialchars($direccion) ?></span>
                    </div>
                    <div class="pedido-info-row">
                        <span>Método de pago</span>
                        <span><?= ucfirst($metodo) ?></span>
                    </div>
                    <div class="pedido-info-row total">
                        <span>Total</span>
                        <span><?= formatPrecio($total) ?></span>
                    </div>
                </div>

                <?php
                $mensaje_wa = "Hola " . SITE_NAME . ", acabo de realizar el pedido #" . SITE_PREFIX . "-" . str_pad($pedido_id, 5, '0', STR_PAD_LEFT) . " por S/ " . number_format($total, 2) . ". Mi nombre es " . $nombre . ". Quiero coordinar la entrega.";
                ?>
                <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>?text=<?= urlencode($mensaje_wa) ?>" 
                   class="btn-whatsapp-checkout" style="max-width:300px; margin:0 auto;">
                    <i class="fa-brands fa-whatsapp"></i> Confirmar por WhatsApp
                </a>

                <div style="margin-top:24px;">
                    <a href="<?= SITE_URL ?>/index.php" class="btn btn-outline">
                        <i class="fa-solid fa-house"></i> Volver al inicio
                    </a>
                </div>
            </div>
        <?php else: ?>
            <!-- FORMULARIO -->
            <h1 style="font-size:30px; color:var(--verde-oscuro); margin-bottom:24px;">
                <i class="fa-solid fa-credit-card"></i> Finalizar Compra
            </h1>

            <!-- STEPPER -->
            <div class="checkout-stepper">
                <div class="step completed">
                    <div class="num"><i class="fa-solid fa-check"></i></div>
                    <span class="label">Carrito</span>
                </div>
                <div class="step active">
                    <div class="num">2</div>
                    <span class="label">Datos de entrega</span>
                </div>
                <div class="step">
                    <div class="num">3</div>
                    <span class="label">Confirmación</span>
                </div>
            </div>

            <?php if (!empty($errores)): ?>
                <div class="alert alert-danger">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <ul style="margin:0; padding-left:20px;">
                        <?php foreach ($errores as $err): ?>
                            <li><?= htmlspecialchars($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="checkout-layout">
                <!-- FORMULARIO -->
                <form action="" method="POST" data-validate>
                    <div class="checkout-form-card">
                        <h3><i class="fa-solid fa-user"></i> Datos del cliente</h3>
                        <div class="form-row">
                            <div class="form-group">
                                <label>Nombre completo *</label>
                                <input type="text" name="nombre" required value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>" placeholder="Ej. María Quispe">
                            </div>
                            <div class="form-group">
                                <label>Número de celular *</label>
                                <input type="tel" name="celular" required value="<?= htmlspecialchars($_POST['celular'] ?? '') ?>" placeholder="999 999 999">
                            </div>
                        </div>
                    </div>

                    <div class="checkout-form-card">
                        <h3><i class="fa-solid fa-truck"></i> Datos de entrega</h3>
                        <div class="form-group">
                            <label>Dirección de entrega *</label>
                            <input type="text" name="direccion" required value="<?= htmlspecialchars($_POST['direccion'] ?? '') ?>" placeholder="Av. / Jr. / Calle, número">
                        </div>
                        <div class="form-group">
                            <label>Referencia de ubicación</label>
                            <input type="text" name="referencia" value="<?= htmlspecialchars($_POST['referencia'] ?? '') ?>" placeholder="Ej. Frente al parque, casa azul, etc.">
                        </div>
                        <div class="form-group">
                            <label>Observaciones (opcional)</label>
                            <textarea name="observaciones" placeholder="Indicaciones especiales para la entrega..."></textarea>
                        </div>
                    </div>

                    <div class="checkout-form-card">
                        <h3><i class="fa-solid fa-wallet"></i> Método de pago</h3>
                        <div class="pago-options">
                            <label class="pago-option">
                                <input type="radio" name="metodo_pago" value="efectivo" checked>
                                <div class="icon efectivo"><i class="fa-solid fa-money-bill-wave"></i></div>
                                <div class="text">
                                    <strong>Efectivo</strong>
                                    <span>Paga al recibir</span>
                                </div>
                            </label>
                            <label class="pago-option">
                                <input type="radio" name="metodo_pago" value="yape">
                                <div class="icon yape"><i class="fa-solid fa-mobile-screen"></i></div>
                                <div class="text">
                                    <strong>Yape</strong>
                                    <span>Pago móvil</span>
                                </div>
                            </label>
                            <label class="pago-option">
                                <input type="radio" name="metodo_pago" value="plin">
                                <div class="icon plin"><i class="fa-solid fa-mobile-screen-button"></i></div>
                                <div class="text">
                                    <strong>Plin</strong>
                                    <span>Pago móvil</span>
                                </div>
                            </label>
                            <label class="pago-option">
                                <input type="radio" name="metodo_pago" value="transferencia">
                                <div class="icon transferencia"><i class="fa-solid fa-building-columns"></i></div>
                                <div class="text">
                                    <strong>Transferencia</strong>
                                    <span>BCP / Interbank</span>
                                </div>
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary btn-block btn-lg">
                        <i class="fa-solid fa-check"></i> Confirmar pedido
                    </button>
                </form>

                <!-- RESUMEN -->
                <div class="checkout-resumen">
                    <h3><i class="fa-solid fa-receipt"></i> Tu pedido</h3>
                    <div class="resumen-productos">
                        <?php foreach ($carrito as $item): ?>
                            <div class="resumen-producto">
                                <div class="img">
                                    <img src="<?= htmlspecialchars(normalizarImagen($item['imagen'])) ?>" alt="<?= htmlspecialchars($item['nombre']) ?>"
                                         onerror="this.src='https://via.placeholder.com/80/0E5A3C/FFFFFF?text=ZAI'">
                                </div>
                                <div class="info">
                                    <h5><?= htmlspecialchars($item['nombre']) ?></h5>
                                    <p><?= $item['cantidad'] ?> × <?= formatPrecio($item['precio']) ?></p>
                                </div>
                                <div class="precio">
                                    <?= formatPrecio($item['precio'] * $item['cantidad']) ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="resumen-linea">
                        <span>Subtotal</span>
                        <span><?= formatPrecio($total) ?></span>
                    </div>
                    <div class="resumen-linea">
                        <span>Envío</span>
                        <span style="color:var(--verde-claro-2); font-weight:600;">Gratis</span>
                    </div>
                    <div class="resumen-total">
                        <span>Total</span>
                        <span style="color:var(--verde-oscuro); font-size:22px; font-weight:800;"><?= formatPrecio($total) ?></span>
                    </div>

                    <div style="background:var(--gris-claro); padding:14px; border-radius:var(--radius-md); margin-top:14px; font-size:12px; color:var(--gris-texto);">
                        <i class="fa-solid fa-shield-halved" style="color:var(--verde-claro-2);"></i> 
                        Tus datos están seguros. No compartimos información con terceros.
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<script>
// Seleccionar método de pago visual
document.querySelectorAll('.pago-option').forEach(function(opt) {
    opt.addEventListener('click', function() {
        document.querySelectorAll('.pago-option').forEach(function(o) { o.classList.remove('selected'); });
        this.classList.add('selected');
        this.querySelector('input[type="radio"]').checked = true;
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
