<?php
/**
 * BodegaViva - Login / Registro de clientes
 */
if (!ob_get_level()) { ob_start(); }
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// Si ya está logueado, ir al inicio
if (isCliente()) {
    header('Location: ' . SITE_URL . '/pages/perfil.php');
    echo '<script>window.location.href="' . SITE_URL . '/pages/perfil.php";</script>';
    exit;
}

$redirect = $_GET['redirect'] ?? SITE_URL . '/index.php';
$tab = $_GET['tab'] ?? 'login';
$errores = [];

// Procesar login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $recordar = isset($_POST['recordar']);
    
    if (empty($email) || empty($password)) {
        $errores[] = 'Completa todos los campos';
    } elseif (loginCliente($email, $password, $recordar)) {
        flash('success', '¡Bienvenido de nuevo!');
        header('Location: ' . $redirect);
        echo '<script>window.location.href="' . $redirect . '";</script>';
        exit;
    } else {
        $errores[] = 'Email o contraseña incorrectos';
    }
}

// Procesar registro
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'registro') {
    $resultado = registrarCliente($_POST);
    if ($resultado['success']) {
        // Auto-login después de registro
        loginCliente($_POST['email'], $_POST['password']);
        flash('success', '¡Cuenta creada! Bienvenido a ' . SITE_NAME);
        header('Location: ' . $redirect);
        echo '<script>window.location.href="' . $redirect . '";</script>';
        exit;
    } else {
        $errores = $resultado['errores'];
        $tab = 'registro';
    }
}

$pagina_activa = 'login';
$titulo = 'Iniciar Sesión';
$css_extra = ['carrito.css'];

include __DIR__ . '/../includes/header.php';
?>

<!-- HERO -->
<section class="page-hero" style="background: linear-gradient(120deg, #0E5A3C, #5DA838);">
    <div class="container">
        <h1><i class="fa-solid fa-user-shield"></i> Mi Cuenta</h1>
        <p>Inicia sesión o crea una cuenta para disfrutar de beneficios exclusivos.</p>
    </div>
</section>

<section class="container" style="padding:50px 0; max-width:520px;">
    
    <!-- Tabs -->
    <div class="auth-tabs" style="display:flex; background:var(--blanco); border-radius:30px; padding:6px; margin-bottom:30px; box-shadow:var(--sombra-1);">
        <button class="auth-tab <?= $tab === 'login' ? 'active' : '' ?>" onclick="switchTab('login')" 
                style="flex:1; padding:14px; border-radius:24px; font-weight:600; font-size:14px; transition:all 0.3s; border:none; cursor:pointer; background:<?= $tab === 'login' ? 'var(--verde-oscuro)' : 'transparent' ?>; color:<?= $tab === 'login' ? 'white' : 'var(--texto-2)' ?>;">
            <i class="fa-solid fa-right-to-bracket"></i> Iniciar Sesión
        </button>
        <button class="auth-tab <?= $tab === 'registro' ? 'active' : '' ?>" onclick="switchTab('registro')"
                style="flex:1; padding:14px; border-radius:24px; font-weight:600; font-size:14px; transition:all 0.3s; border:none; cursor:pointer; background:<?= $tab === 'registro' ? 'var(--verde-oscuro)' : 'transparent' ?>; color:<?= $tab === 'registro' ? 'white' : 'var(--texto-2)' ?>;">
            <i class="fa-solid fa-user-plus"></i> Crear Cuenta
        </button>
    </div>
    
    <?php if (!empty($errores)): ?>
        <div class="alert alert-danger" style="background:rgba(229,57,53,0.1); padding:14px; border-radius:10px; border-left:4px solid var(--rojo); margin-bottom:20px; display:flex; gap:10px; align-items:flex-start;">
            <i class="fa-solid fa-circle-exclamation" style="color:var(--rojo); margin-top:2px;"></i>
            <div>
                <strong style="display:block; margin-bottom:4px;">Hubo errores:</strong>
                <ul style="margin:0; padding-left:18px; font-size:13px;">
                    <?php foreach ($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
                </ul>
            </div>
        </div>
    <?php endif; ?>
    
    <!-- Form Login -->
    <div id="tab-login" class="auth-content" style="display:<?= $tab === 'login' ? 'block' : 'none' ?>;">
        <div style="background:var(--blanco); padding:30px; border-radius:var(--radius-lg); box-shadow:var(--sombra-2);">
            <h2 style="font-size:24px; color:var(--verde-oscuro); margin-bottom:6px;">Bienvenido de vuelta</h2>
            <p style="color:var(--gris-texto); font-size:14px; margin-bottom:24px;">Ingresa con tu email y contraseña.</p>
            
            <form method="POST" data-validate>
                <input type="hidden" name="action" value="login">
                <div class="form-group" style="margin-bottom:16px;">
                    <label style="font-size:13px; font-weight:600; color:var(--texto); display:block; margin-bottom:6px;">Email</label>
                    <div style="position:relative;">
                        <i class="fa-solid fa-envelope" style="position:absolute; left:14px; top:50%; transform:translateY(-50%); color:var(--gris-texto);"></i>
                        <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" 
                               placeholder="tucorreo@email.com"
                               style="width:100%; padding:12px 14px 12px 42px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); outline:none; transition:all 0.2s; font-size:14px;"
                               onfocus="this.style.borderColor='var(--verde-claro)'; this.style.boxShadow='0 0 0 3px rgba(123,201,80,0.15)'"
                               onblur="this.style.borderColor='var(--gris-3)'; this.style.boxShadow='none'">
                    </div>
                </div>
                <div class="form-group" style="margin-bottom:16px;">
                    <label style="font-size:13px; font-weight:600; color:var(--texto); display:block; margin-bottom:6px;">Contraseña</label>
                    <div style="position:relative;">
                        <i class="fa-solid fa-lock" style="position:absolute; left:14px; top:50%; transform:translateY(-50%); color:var(--gris-texto);"></i>
                        <input type="password" name="password" required placeholder="••••••••" id="passwordLogin"
                               style="width:100%; padding:12px 42px 12px 42px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); outline:none; transition:all 0.2s; font-size:14px;"
                               onfocus="this.style.borderColor='var(--verde-claro)'; this.style.boxShadow='0 0 0 3px rgba(123,201,80,0.15)'"
                               onblur="this.style.borderColor='var(--gris-3)'; this.style.boxShadow='none'">
                        <button type="button" onclick="togglePassword('passwordLogin', this)" style="position:absolute; right:10px; top:50%; transform:translateY(-50%); background:none; border:none; cursor:pointer; color:var(--gris-texto);">
                            <i class="fa-solid fa-eye"></i>
                        </button>
                    </div>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
                    <label style="display:flex; align-items:center; gap:6px; cursor:pointer; font-size:13px;">
                        <input type="checkbox" name="recordar"> Recordarme
                    </label>
                    <a href="#" style="color:var(--verde-claro-2); font-size:13px; text-decoration:none;">¿Olvidaste tu contraseña?</a>
                </div>
                <button type="submit" class="btn-loader" style="width:100%; background:var(--verde-oscuro); color:white; padding:14px; border-radius:var(--radius-sm); font-weight:600; font-size:15px; border:none; cursor:pointer; transition:all 0.3s;">
                    <span class="btn-text"><i class="fa-solid fa-right-to-bracket"></i> Iniciar Sesión</span>
                    <span class="btn-loading" style="display:none;"><i class="fa-solid fa-spinner fa-spin"></i> Procesando...</span>
                </button>
            </form>
            
            <div style="text-align:center; margin-top:20px; padding-top:20px; border-top:1px solid var(--gris-2);">
                <p style="font-size:13px; color:var(--gris-texto);">¿No tienes cuenta? 
                    <a href="#" onclick="switchTab('registro')" style="color:var(--verde-oscuro); font-weight:600;">Regístrate aquí</a>
                </p>
            </div>
        </div>
    </div>
    
    <!-- Form Registro -->
    <div id="tab-registro" class="auth-content" style="display:<?= $tab === 'registro' ? 'block' : 'none' ?>;">
        <div style="background:var(--blanco); padding:30px; border-radius:var(--radius-lg); box-shadow:var(--sombra-2);">
            <h2 style="font-size:24px; color:var(--verde-oscuro); margin-bottom:6px;">Crea tu cuenta</h2>
            <p style="color:var(--gris-texto); font-size:14px; margin-bottom:24px;">Únete y disfruta de beneficios exclusivos.</p>
            
            <form method="POST" data-validate>
                <input type="hidden" name="action" value="registro">
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Nombre completo *</label>
                    <input type="text" name="nombre" required value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>" placeholder="Ej. María Quispe"
                           style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); outline:none; font-size:14px;">
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:14px;">
                    <div class="form-group">
                        <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Celular *</label>
                        <input type="tel" name="celular" required value="<?= htmlspecialchars($_POST['celular'] ?? '') ?>" placeholder="999999999" maxlength="9"
                               style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); outline:none; font-size:14px;">
                    </div>
                    <div class="form-group">
                        <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Email *</label>
                        <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" placeholder="email@ejemplo.com"
                               style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); outline:none; font-size:14px;">
                    </div>
                </div>
                <div class="form-group" style="margin-bottom:14px;">
                    <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Dirección</label>
                    <input type="text" name="direccion" value="<?= htmlspecialchars($_POST['direccion'] ?? '') ?>" placeholder="Av. / Jr. / Calle, número"
                           style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); outline:none; font-size:14px;">
                </div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:12px; margin-bottom:20px;">
                    <div class="form-group">
                        <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Contraseña *</label>
                        <input type="password" name="password" required id="passwordReg" placeholder="Mínimo 6 caracteres"
                               style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); outline:none; font-size:14px;"
                               oninput="checkPasswordStrength(this.value)">
                    </div>
                    <div class="form-group">
                        <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Confirmar *</label>
                        <input type="password" name="password_confirm" required id="passwordConfirm" placeholder="Repetir contraseña"
                               style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); outline:none; font-size:14px;"
                               oninput="checkMatch()">
                    </div>
                </div>
                <!-- Indicador fuerza contraseña -->
                <div id="pwdStrength" style="margin-bottom:16px; font-size:12px; display:none;">
                    <div style="display:flex; gap:4px; margin-bottom:4px;">
                        <div class="pwd-bar" style="flex:1; height:4px; background:var(--gris-2); border-radius:2px;"></div>
                        <div class="pwd-bar" style="flex:1; height:4px; background:var(--gris-2); border-radius:2px;"></div>
                        <div class="pwd-bar" style="flex:1; height:4px; background:var(--gris-2); border-radius:2px;"></div>
                        <div class="pwd-bar" style="flex:1; height:4px; background:var(--gris-2); border-radius:2px;"></div>
                    </div>
                    <span id="pwdText" style="color:var(--gris-texto);"></span>
                </div>
                <div id="pwdMatch" style="margin-bottom:16px; font-size:12px;"></div>
                
                <label style="display:flex; align-items:flex-start; gap:8px; margin-bottom:20px; cursor:pointer; font-size:13px;">
                    <input type="checkbox" name="terminos" required style="margin-top:3px;">
                    <span>Acepto los <a href="#" style="color:var(--verde-oscuro);">Términos y Condiciones</a> y la <a href="#" style="color:var(--verde-oscuro);">Política de Privacidad</a></span>
                </label>
                
                <button type="submit" class="btn-loader" style="width:100%; background:var(--verde-claro-2); color:white; padding:14px; border-radius:var(--radius-sm); font-weight:600; font-size:15px; border:none; cursor:pointer; transition:all 0.3s;">
                    <span class="btn-text"><i class="fa-solid fa-user-plus"></i> Crear Cuenta</span>
                    <span class="btn-loading" style="display:none;"><i class="fa-solid fa-spinner fa-spin"></i> Creando...</span>
                </button>
            </form>
            
            <div style="text-align:center; margin-top:20px; padding-top:20px; border-top:1px solid var(--gris-2);">
                <p style="font-size:13px; color:var(--gris-texto);">¿Ya tienes cuenta? 
                    <a href="#" onclick="switchTab('login')" style="color:var(--verde-oscuro); font-weight:600;">Inicia sesión</a>
                </p>
            </div>
        </div>
    </div>
</section>

<script>
function switchTab(tab) {
    document.querySelectorAll('.auth-content').forEach(el => el.style.display = 'none');
    document.getElementById('tab-' + tab).style.display = 'block';
    document.querySelectorAll('.auth-tab').forEach((btn, i) => {
        if ((i === 0 && tab === 'login') || (i === 1 && tab === 'registro')) {
            btn.style.background = 'var(--verde-oscuro)';
            btn.style.color = 'white';
            btn.classList.add('active');
        } else {
            btn.style.background = 'transparent';
            btn.style.color = 'var(--texto-2)';
            btn.classList.remove('active');
        }
    });
    // Actualizar URL sin recargar
    const url = new URL(window.location);
    url.searchParams.set('tab', tab);
    window.history.replaceState({}, '', url);
}

function togglePassword(id, btn) {
    const input = document.getElementById(id);
    const icon = btn.querySelector('i');
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

function checkPasswordStrength(pwd) {
    const strength = document.getElementById('pwdStrength');
    const text = document.getElementById('pwdText');
    const bars = strength.querySelectorAll('.pwd-bar');
    if (!pwd) {
        strength.style.display = 'none';
        return;
    }
    strength.style.display = 'block';
    let score = 0;
    if (pwd.length >= 6) score++;
    if (pwd.length >= 10) score++;
    if (/[A-Z]/.test(pwd) && /[a-z]/.test(pwd)) score++;
    if (/\d/.test(pwd) || /[^a-zA-Z0-9]/.test(pwd)) score++;
    const colors = ['#E53935', '#FB8C00', '#FFD23F', '#7BC950'];
    const labels = ['Muy débil', 'Débil', 'Buena', 'Fuerte'];
    bars.forEach((bar, i) => {
        bar.style.background = i < score ? colors[score-1] : 'var(--gris-2)';
    });
    text.textContent = labels[score-1] || 'Muy débil';
    text.style.color = colors[score-1] || 'var(--gris-texto)';
}

function checkMatch() {
    const pwd = document.getElementById('passwordReg').value;
    const confirm = document.getElementById('passwordConfirm').value;
    const match = document.getElementById('pwdMatch');
    if (!confirm) {
        match.innerHTML = '';
        return;
    }
    if (pwd === confirm) {
        match.innerHTML = '<i class="fa-solid fa-check"></i> Las contraseñas coinciden';
        match.style.color = 'var(--verde-claro-2)';
    } else {
        match.innerHTML = '<i class="fa-solid fa-xmark"></i> Las contraseñas no coinciden';
        match.style.color = 'var(--rojo)';
    }
}

// Botones con loading
document.querySelectorAll('.btn-loader').forEach(btn => {
    btn.addEventListener('click', function() {
        const form = this.closest('form');
        if (form && form.checkValidity()) {
            this.querySelector('.btn-text').style.display = 'none';
            this.querySelector('.btn-loading').style.display = 'inline';
            this.style.opacity = '0.8';
        }
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
