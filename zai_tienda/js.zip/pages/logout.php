<?php
/**
 * BodegaViva - Cerrar sesión cliente
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

logoutCliente();
header('Location: ' . SITE_URL . '/index.php');
echo '<script>window.location.href="' . SITE_URL . '/index.php";</script>';
exit;
