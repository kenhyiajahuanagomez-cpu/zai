<?php
/**
 * ZAI - Página de Contacto
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$pagina_activa = 'contacto';
$titulo = 'Contacto';
$css_extra = ['tienda.css'];

$errores = [];
$enviado = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = limpiar($_POST['nombre'] ?? '');
    $email = filter_var($_POST['email'] ?? '', FILTER_VALIDATE_EMAIL);
    $celular = limpiar($_POST['celular'] ?? '');
    $asunto = limpiar($_POST['asunto'] ?? '');
    $mensaje = limpiar($_POST['mensaje'] ?? '');

    if (empty($nombre)) $errores[] = 'El nombre es obligatorio';
    if (!$email) $errores[] = 'El email no es válido';
    if (empty($celular)) $errores[] = 'El celular es obligatorio';
    if (empty($mensaje)) $errores[] = 'El mensaje es obligatorio';

    if (empty($errores)) {
        // En un sistema real se guardaría en BD y/o se enviaría por email
        $enviado = true;
        flash('success', '¡Mensaje enviado! Te contactaremos pronto.');
    }
}

include __DIR__ . '/../includes/header.php';
?>

<!-- HERO -->
<section class="page-hero">
    <div class="container">
        <h1><i class="fa-solid fa-headset"></i> Contáctanos</h1>
        <p>Estamos para ayudarte. Escríbenos por WhatsApp, llámanos o visítanos en nuestra tienda.</p>
    </div>
</section>

<nav class="breadcrumb">
    <div class="container">
        <ul>
            <li><a href="<?= SITE_URL ?>/index.php">Inicio</a></li>
            <li>Contacto</li>
        </ul>
    </div>
</nav>

<section class="contacto-layout">
    <div class="container" style="grid-column: 1 / -1;">
        <div class="contacto-layout" style="display:grid; grid-template-columns:1fr 1.2fr; gap:30px;">
            <!-- INFO -->
            <div class="contacto-info reveal">
                <h2>Información de contacto</h2>
                <div class="contacto-info-item">
                    <div class="icon"><i class="fa-solid fa-location-dot"></i></div>
                    <div class="info">
                        <h4>Dirección</h4>
                        <p><?= STORE_ADDRESS ?></p>
                    </div>
                </div>
                <div class="contacto-info-item">
                    <div class="icon"><i class="fa-solid fa-phone"></i></div>
                    <div class="info">
                        <h4>Teléfono</h4>
                        <p><?= CONTACT_PHONE ?></p>
                    </div>
                </div>
                <div class="contacto-info-item">
                    <div class="icon"><i class="fa-brands fa-whatsapp"></i></div>
                    <div class="info">
                        <h4>WhatsApp</h4>
                        <p>+<?= WHATSAPP_NUMBER ?></p>
                    </div>
                </div>
                <div class="contacto-info-item">
                    <div class="icon"><i class="fa-solid fa-envelope"></i></div>
                    <div class="info">
                        <h4>Email</h4>
                        <p><?= SITE_EMAIL ?></p>
                    </div>
                </div>
                <div class="contacto-info-item">
                    <div class="icon"><i class="fa-solid fa-clock"></i></div>
                    <div class="info">
                        <h4>Horario</h4>
                        <p><?= STORE_HOURS ?></p>
                    </div>
                </div>
                <div class="social">
                    <a href="#" aria-label="Facebook"><i class="fa-brands fa-facebook-f"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fa-brands fa-instagram"></i></a>
                    <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>" aria-label="WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
                    <a href="#" aria-label="TikTok"><i class="fa-brands fa-tiktok"></i></a>
                </div>
            </div>

            <!-- FORMULARIO -->
            <div class="contacto-form reveal reveal-delay-1">
                <h2>Envíanos un mensaje</h2>
                <p class="subtitle">Completa el formulario y te responderemos a la brevedad.</p>

                <?php if (!empty($errores)): ?>
                    <div class="alert alert-danger">
                        <i class="fa-solid fa-circle-exclamation"></i>
                        <ul style="margin:0; padding-left:20px;">
                            <?php foreach ($errores as $err): ?>
                                <li><?= htmlspecialchars($err) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <?php if ($enviado): ?>
                    <div class="alert alert-success">
                        <i class="fa-solid fa-circle-check"></i> ¡Gracias por tu mensaje! Te contactaremos pronto.
                    </div>
                <?php endif; ?>

                <form action="" method="POST" data-validate>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Nombre completo *</label>
                            <input type="text" name="nombre" required value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>" placeholder="Tu nombre">
                        </div>
                        <div class="form-group">
                            <label>Celular *</label>
                            <input type="tel" name="celular" required value="<?= htmlspecialchars($_POST['celular'] ?? '') ?>" placeholder="999 999 999">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Email *</label>
                            <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>" placeholder="tucorreo@email.com">
                        </div>
                        <div class="form-group">
                            <label>Asunto</label>
                            <select name="asunto">
                                <option value="">Selecciona...</option>
                                <option value="consulta">Consulta general</option>
                                <option value="pedido">Sobre un pedido</option>
                                <option value="mayorista">Precios mayoristas</option>
                                <option value="reclamo">Reclamo o sugerencia</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Mensaje *</label>
                        <textarea name="mensaje" required placeholder="Escribe tu mensaje aquí..."><?= htmlspecialchars($_POST['mensaje'] ?? '') ?></textarea>
                    </div>
                    <div style="display:flex; gap:10px; flex-wrap:wrap;">
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="fa-solid fa-paper-plane"></i> Enviar mensaje
                        </button>
                        <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>?text=<?= urlencode('Hola ' . SITE_NAME . ', quisiera información.') ?>" 
                           class="btn btn-outline btn-lg" style="background:#25D366; color:white; border-color:#25D366;">
                            <i class="fa-brands fa-whatsapp"></i> WhatsApp
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- MAPA -->
<section class="container" style="padding:0 0 60px;">
    <div class="mapa-embed">
        <iframe 
            src="https://www.openstreetmap.org/export/embed.html?bbox=-77.06%2C-12.02%2C-76.96%2C-11.95&layer=mapnik&marker=-11.97%2C-77.01" 
            loading="lazy" 
            title="Ubicación <?= SITE_NAME ?>"></iframe>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
