<?php
/**
 * ZAI - Página Nosotros
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$pagina_activa = 'nosotros';
$titulo = 'Nosotros';
$css_extra = ['tienda.css'];

include __DIR__ . '/../includes/header.php';
?>

<!-- HERO -->
<section class="nosotros-hero">
    <div class="container">
        <h1>Sobre <span style="color:var(--amarillo);"><?= SITE_NAME ?></span></h1>
        <p>Más que una tienda, somos parte de tu barrio. Conoce nuestra historia y compromiso con cada cliente.</p>
    </div>
</section>

<nav class="breadcrumb">
    <div class="container">
        <ul>
            <li><a href="<?= SITE_URL ?>/index.php">Inicio</a></li>
            <li>Nosotros</li>
        </ul>
    </div>
</nav>

<!-- HISTORIA -->
<section class="section">
    <div class="container">
        <div class="historia-section">
            <div class="historia-img reveal">
                <img src="https://images.unsplash.com/photo-1568992687947-868a62a9f521?w=700&q=80" alt="Tienda <?= SITE_NAME ?>">
            </div>
            <div class="historia-text reveal reveal-delay-1">
                <span class="section-eyebrow">Nuestra Historia</span>
                <h2>Una bodega con tradición y modernidad</h2>
                <p><?= SITE_NAME ?> nació en el año 2010 como una pequeña bodega de barrio en San Juan de Lurigancho, Lima. Lo que empezó como un sueño familiar de ofrecer productos frescos y de calidad a precios justos, hoy se ha convertido en una tienda de abarrotes moderna y reconocida.</p>
                <p>Inspirados en la calidez de las bodegas peruanas, hemos combinado la tradición con la tecnología. Ahora, además de atender en nuestra tienda física, llevamos nuestros productos directamente a tu hogar con solo unos clics.</p>
                <p>Nuestro compromiso es claro: ofrecer productos frescos, marcas reconocidas, precios justos y un servicio cercano y amable. Porque para nosotros, cada cliente es parte de la familia <?= SITE_NAME ?>.</p>
            </div>
        </div>
    </div>
</section>

<!-- STATS -->
<section class="stats-section">
    <div class="container">
        <div class="stats-grid">
            <div class="stat-item reveal">
                <strong data-counter="15">0</strong>
                <span>Años de experiencia</span>
            </div>
            <div class="stat-item reveal reveal-delay-1">
                <strong data-counter="500">0</strong>
                <span>Productos disponibles</span>
            </div>
            <div class="stat-item reveal reveal-delay-2">
                <strong data-counter="2500">0</strong>
                <span>Clientes satisfechos</span>
            </div>
            <div class="stat-item reveal reveal-delay-3">
                <strong data-counter="30">0</strong>
                <span>Minutos de entrega</span>
            </div>
        </div>
    </div>
</section>

<!-- MISIÓN Y VISIÓN -->
<section class="section">
    <div class="container">
        <div class="section-header center reveal">
            <span class="section-eyebrow">Nuestra razón de ser</span>
            <h2 class="section-title">Misión y <span class="highlight">Visión</span></h2>
        </div>
        <div class="mision-vision">
            <div class="mv-card reveal">
                <div class="icon"><i class="fa-solid fa-bullseye"></i></div>
                <h3>Misión</h3>
                <p>Brindar a las familias peruanas productos de abarrotes de primera calidad, a precios accesibles y con un servicio cercano y oportuno. Ser la bodega de confianza que combine la calidez de las bodegas tradicionales con la comodidad de la tecnología moderna.</p>
            </div>
            <div class="mv-card reveal reveal-delay-1">
                <div class="icon"><i class="fa-solid fa-eye"></i></div>
                <h3>Visión</h3>
                <p>Ser la tienda de abarrotes en línea líder en Lima, reconocida por la calidad de sus productos, la eficiencia de sus entregas y el trato cercano con sus clientes. Expandir nuestro servicio a todo Perú llevando la bodega <?= SITE_NAME ?> a cada hogar.</p>
            </div>
        </div>
    </div>
</section>

<!-- VALORES -->
<section class="section" style="background:var(--gris-claro);">
    <div class="container">
        <div class="section-header center reveal">
            <span class="section-eyebrow">Lo que nos define</span>
            <h2 class="section-title">Nuestros <span class="highlight">Valores</span></h2>
            <p class="section-subtitle">Los principios que guían cada una de nuestras acciones diarias.</p>
        </div>
        <div class="valores-grid">
            <div class="valor-card reveal">
                <div class="icon"><i class="fa-solid fa-handshake"></i></div>
                <h4>Honestidad</h4>
                <p>Precios transparentes y productos de calidad real.</p>
            </div>
            <div class="valor-card reveal reveal-delay-1">
                <div class="icon"><i class="fa-solid fa-heart"></i></div>
                <h4>Cercanía</h4>
                <p>Tratamos a cada cliente como a un vecino más.</p>
            </div>
            <div class="valor-card reveal reveal-delay-2">
                <div class="icon"><i class="fa-solid fa-bolt"></i></div>
                <h4>Rapidez</h4>
                <p>Entregamos en el menor tiempo posible.</p>
            </div>
            <div class="valor-card reveal reveal-delay-3">
                <div class="icon"><i class="fa-solid fa-leaf"></i></div>
                <h4>Calidad</h4>
                <p>Solo productos frescos y de marcas reconocidas.</p>
            </div>
        </div>
    </div>
</section>

<!-- COMPROMISO -->
<section class="section">
    <div class="container">
        <div class="section-header center reveal">
            <span class="section-eyebrow">Nuestro compromiso</span>
            <h2 class="section-title">Compromiso con nuestros <span class="highlight">clientes</span></h2>
        </div>
        <div style="background:linear-gradient(135deg, var(--verde-oscuro), var(--verde-claro-2)); border-radius:var(--radius-xl); padding:50px; color:white; max-width:900px; margin:0 auto;">
            <div style="text-align:center;">
                <i class="fa-solid fa-quote-left" style="font-size:30px; color:var(--amarillo); margin-bottom:20px;"></i>
                <p style="font-size:20px; line-height:1.7; margin-bottom:24px; font-style:italic;">
                    "En <?= SITE_NAME ?> nos comprometemos a ofrecerte siempre productos frescos y de calidad, precios justos y un servicio que te haga sentir en casa. Tu satisfacción es nuestra mayor recompensa."
                </p>
                <div style="display:flex; align-items:center; justify-content:center; gap:14px;">
                    <div style="width:60px; height:60px; background:var(--amarillo); border-radius:50%; display:flex; align-items:center; justify-content:center; color:var(--verde-oscuro); font-weight:800; font-size:24px;">B</div>
                    <div style="text-align:left;">
                        <strong style="display:block; font-size:18px;">Equipo <?= SITE_NAME ?></strong>
                        <span style="opacity:0.85; font-size:14px;">Tu bodega de confianza</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include __DIR__ . '/../includes/footer.php'; ?>
