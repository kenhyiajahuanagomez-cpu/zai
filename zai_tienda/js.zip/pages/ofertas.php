<?php
/**
 * ZAI - Página de Ofertas
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$pagina_activa = 'ofertas';
$titulo = 'Ofertas';
$css_extra = ['tienda.css'];
$js_extra = ['cart.js', 'tienda.js'];

$ofertas = obtenerOfertas(20);
$destacados = obtenerDestacados(4);

include __DIR__ . '/../includes/header.php';
?>
<script>var SITE_URL_JS = '<?= SITE_URL ?>';</script>

<!-- HERO -->
<section class="page-hero" style="background: linear-gradient(120deg, #E53935, #FB8C00);">
    <div class="container">
        <h1><i class="fa-solid fa-fire"></i> Ofertas Especiales</h1>
        <p>Descuentos imperdibles en tus productos favoritos. ¡Aprovecha antes de que se agoten!</p>
    </div>
</section>

<nav class="breadcrumb">
    <div class="container">
        <ul>
            <li><a href="<?= SITE_URL ?>/index.php">Inicio</a></li>
            <li>Ofertas</li>
        </ul>
    </div>
</nav>

<section class="ofertas-page">
    <div class="container">
        <!-- OFERTA PRINCIPAL GRANDE -->
        <?php if (!empty($ofertas[0])): 
            $p = $ofertas[0];
            $descuento = calcularDescuento($p['precio'], $p['precio_anterior']);
        ?>
            <div class="oferta-card-grande reveal">
                <div class="img" style="background-image: url('<?= htmlspecialchars(normalizarImagen($p['imagen'])) ?>');">
                    <?php if ($descuento > 0): ?>
                        <div class="descuento-grande">
                            <strong>-<?= $descuento ?>%</strong>
                            <span>OFF</span>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="info">
                    <span class="tag"><i class="fa-solid fa-bolt"></i> Oferta del día</span>
                    <h2><?= htmlspecialchars($p['nombre']) ?></h2>
                    <p><?= htmlspecialchars($p['descripcion']) ?></p>
                    <div class="precios">
                        <span class="actual"><?= formatPrecio($p['precio']) ?></span>
                        <span class="anterior"><?= formatPrecio($p['precio_anterior']) ?></span>
                    </div>
                    <button class="btn-add-cart btn-yellow btn-lg" data-id="<?= $p['id'] ?>" style="width:auto;">
                        <i class="fa-solid fa-cart-plus"></i> Aprovechar oferta
                    </button>
                </div>
            </div>
        <?php endif; ?>

        <!-- COUNTDOWN -->
        <div style="background:var(--blanco); border-radius:var(--radius-lg); padding:30px; text-align:center; margin-bottom:40px; box-shadow:var(--sombra-1);">
            <h3 style="color:var(--verde-oscuro); margin-bottom:10px;"><i class="fa-solid fa-clock"></i> La oferta termina en:</h3>
            <div class="countdown" data-countdown="<?= date('Y-m-d H:i:s', strtotime('+1 day')) ?>" style="margin-top:14px;">
                <div class="countdown-box"><strong data-d>00</strong><span>días</span></div>
                <div class="countdown-box"><strong data-h>00</strong><span>horas</span></div>
                <div class="countdown-box"><strong data-m>00</strong><span>min</span></div>
                <div class="countdown-box"><strong data-s>00</strong><span>seg</span></div>
            </div>
        </div>

        <!-- COMBOS -->
        <h2 style="font-size:28px; color:var(--verde-oscuro); margin-bottom:20px;"><i class="fa-solid fa-box-open"></i> Combos Especiales</h2>
        <div class="combos-grid">
            <div class="combo-card reveal">
                <span class="combo-tag"><i class="fa-solid fa-tag"></i> COMBO 1</span>
                <h3>Combo Desayuno</h3>
                <p class="combo-desc">Incluye: Pan francés, mantequilla, café Altomayo y leche Gloria.</p>
                <div class="combo-precio">
                    <span class="actual">S/ 18.90</span>
                    <span class="anterior">S/ 24.50</span>
                </div>
                <button class="btn btn-yellow" onclick="agregarCombo('Combo Desayuno', 18.90)"><i class="fa-solid fa-cart-plus"></i> Agregar combo</button>
            </div>
            <div class="combo-card reveal reveal-delay-1">
                <span class="combo-tag"><i class="fa-solid fa-tag"></i> COMBO 2</span>
                <h3>Combo Limpieza</h3>
                <p class="combo-desc">Incluye: Detergente Bolívar, jabón Opal, lejía y limpiador multiusos.</p>
                <div class="combo-precio">
                    <span class="actual">S/ 28.50</span>
                    <span class="anterior">S/ 35.00</span>
                </div>
                <button class="btn btn-yellow" onclick="agregarCombo('Combo Limpieza', 28.50)"><i class="fa-solid fa-cart-plus"></i> Agregar combo</button>
            </div>
            <div class="combo-card reveal reveal-delay-2">
                <span class="combo-tag"><i class="fa-solid fa-tag"></i> COMBO 3</span>
                <h3>Combo Snacks</h3>
                <p class="combo-desc">Incluye: Papas Lay's, chocolates Sublime, galletas Soda y Inca Kola.</p>
                <div class="combo-precio">
                    <span class="actual">S/ 15.90</span>
                    <span class="anterior">S/ 22.00</span>
                </div>
                <button class="btn btn-yellow" onclick="agregarCombo('Combo Snacks', 15.90)"><i class="fa-solid fa-cart-plus"></i> Agregar combo</button>
            </div>
        </div>

        <!-- TODAS LAS OFERTAS -->
        <h2 style="font-size:28px; color:var(--verde-oscuro); margin:50px 0 20px;"><i class="fa-solid fa-tags"></i> Todas las Ofertas</h2>
        <div class="productos-grid">
            <?php foreach ($ofertas as $p): ?>
                <?php include __DIR__ . '/../includes/_producto_card.php'; ?>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<script>
function agregarCombo(nombre, precio) {
    if (window.ZAIToast) {
        ZAIToast('success', 'Combo agregado', nombre + ' - S/ ' + precio.toFixed(2));
    }
    // Aquí se podría hacer fetch al carrito real
    fetch(SITE_URL_JS + '/pages/carrito.php?action=add_combo', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'nombre=' + encodeURIComponent(nombre) + '&precio=' + precio
    }).then(r => r.json()).then(data => {
        if (data.success) {
            const counter = document.getElementById('cartCount');
            if (counter) {
                counter.textContent = data.cantidad;
                counter.style.display = 'flex';
            }
        }
    }).catch(() => {});
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
