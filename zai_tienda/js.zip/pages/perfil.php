<?php
/**
 * BodegaViva - Perfil del cliente
 */
if (!ob_get_level()) { ob_start(); }
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

requireCliente();

$cliente = getCliente();
$cliente_id = $cliente['id'];
$mensaje = '';
$errores = [];

// Procesar actualización de perfil
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'actualizar_perfil') {
        $nombre = trim($_POST['nombre'] ?? '');
        $celular = trim($_POST['celular'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $direccion = trim($_POST['direccion'] ?? '');
        $referencia = trim($_POST['referencia'] ?? '');
        
        if (empty($nombre)) $errores[] = 'El nombre es obligatorio';
        if (empty($celular)) $errores[] = 'El celular es obligatorio';
        if (empty($email)) $errores[] = 'El email es obligatorio';
        
        if (empty($errores)) {
            $db->execute(
                "UPDATE clientes SET nombre=?, celular=?, email=?, direccion=?, referencia=? WHERE id=?",
                ['sssssi', $nombre, $celular, $email, $direccion, $referencia, $cliente_id]
            );
            $_SESSION['cliente_nombre'] = $nombre;
            $_SESSION['cliente_email'] = $email;
            flash('success', 'Perfil actualizado correctamente.');
            header('Location: ' . SITE_URL . '/pages/perfil.php');
            echo '<script>window.location.href="' . SITE_URL . '/pages/perfil.php";</script>';
            exit;
        }
    } elseif ($_POST['action'] === 'cambiar_password') {
        $actual = $_POST['password_actual'] ?? '';
        $nueva = $_POST['password_nueva'] ?? '';
        $confirmar = $_POST['password_confirmar'] ?? '';
        
        if (empty($actual) || empty($nueva) || empty($confirmar)) {
            $errores[] = 'Completa todos los campos de contraseña';
        } elseif (strlen($nueva) < 6) {
            $errores[] = 'La nueva contraseña debe tener al menos 6 caracteres';
        } elseif ($nueva !== $confirmar) {
            $errores[] = 'Las contraseñas nuevas no coinciden';
        } else {
            $cli = $db->fetchOne("SELECT password FROM clientes WHERE id = ?", ['i', $cliente_id]);
            if ($cli && password_verify($actual, $cli['password'])) {
                $hash = password_hash($nueva, PASSWORD_DEFAULT);
                $db->execute("UPDATE clientes SET password=? WHERE id=?", ['si', $hash, $cliente_id]);
                flash('success', 'Contraseña actualizada.');
                header('Location: ' . SITE_URL . '/pages/perfil.php?tab=seguridad');
                echo '<script>window.location.href="' . SITE_URL . '/pages/perfil.php?tab=seguridad";</script>';
                exit;
            } else {
                $errores[] = 'La contraseña actual es incorrecta';
            }
        }
    }
}

// Obtener pedidos del cliente
$pedidos = $db->fetchAll(
    "SELECT * FROM pedidos WHERE cliente_id = ? ORDER BY fecha_pedido DESC",
    ['i', $cliente_id]
);

$total_pedidos = count($pedidos);
$total_gastado = 0;
foreach ($pedidos as $p) {
    if ($p['estado'] === 'entregado') $total_gastado += $p['total'];
}

$tab = $_GET['tab'] ?? 'perfil';

$pagina_activa = 'perfil';
$titulo = 'Mi Perfil';
$css_extra = ['carrito.css'];

include __DIR__ . '/../includes/header.php';
?>

<!-- HERO -->
<section class="page-hero" style="background: linear-gradient(120deg, #0E5A3C, #5DA838);">
    <div class="container">
        <h1><i class="fa-solid fa-user-circle"></i> Hola, <?= htmlspecialchars($cliente['nombre']) ?>!</h1>
        <p>Gestiona tu cuenta, revisa tus pedidos y mantén tus datos actualizados.</p>
    </div>
</section>

<section class="container" style="padding:40px 0;">
    
    <?php foreach (getFlash() as $f): ?>
        <div class="alert alert-<?= $f['tipo'] ?>" style="background:rgba(123,201,80,0.12); padding:14px 18px; border-radius:10px; border-left:4px solid var(--verde-claro); margin-bottom:20px; display:flex; gap:10px; align-items:center;">
            <i class="fa-solid fa-circle-<?= $f['tipo'] === 'success' ? 'check' : 'info' ?>" style="color:var(--verde-claro-2);"></i>
            <?= htmlspecialchars($f['mensaje']) ?>
        </div>
    <?php endforeach; ?>
    
    <?php if (!empty($errores)): ?>
        <div class="alert alert-danger" style="background:rgba(229,57,53,0.1); padding:14px 18px; border-radius:10px; border-left:4px solid var(--rojo); margin-bottom:20px;">
            <ul style="margin:0; padding-left:18px;">
                <?php foreach ($errores as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    
    <!-- Stats -->
    <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:16px; margin-bottom:30px;">
        <div style="background:var(--blanco); padding:20px; border-radius:var(--radius-md); box-shadow:var(--sombra-1); text-align:center;">
            <div style="width:50px; height:50px; background:var(--verde-claro); border-radius:12px; display:flex; align-items:center; justify-content:center; margin:0 auto 10px; color:white; font-size:20px;">
                <i class="fa-solid fa-receipt"></i>
            </div>
            <strong style="font-size:24px; color:var(--verde-oscuro); display:block;"><?= $total_pedidos ?></strong>
            <span style="font-size:13px; color:var(--gris-texto);">Pedidos realizados</span>
        </div>
        <div style="background:var(--blanco); padding:20px; border-radius:var(--radius-md); box-shadow:var(--sombra-1); text-align:center;">
            <div style="width:50px; height:50px; background:var(--amarillo); border-radius:12px; display:flex; align-items:center; justify-content:center; margin:0 auto 10px; color:var(--verde-oscuro); font-size:20px;">
                <i class="fa-solid fa-coins"></i>
            </div>
            <strong style="font-size:24px; color:var(--verde-oscuro); display:block;"><?= formatPrecio($total_gastado) ?></strong>
            <span style="font-size:13px; color:var(--gris-texto);">Total gastado</span>
        </div>
        <div style="background:var(--blanco); padding:20px; border-radius:var(--radius-md); box-shadow:var(--sombra-1); text-align:center;">
            <div style="width:50px; height:50px; background:var(--naranja); border-radius:12px; display:flex; align-items:center; justify-content:center; margin:0 auto 10px; color:white; font-size:20px;">
                <i class="fa-solid fa-medal"></i>
            </div>
            <strong style="font-size:24px; color:var(--verde-oscuro); display:block;">Plata</strong>
            <span style="font-size:13px; color:var(--gris-texto);">Cliente desde <?= date('Y', strtotime($cliente['fecha_registro'])) ?></span>
        </div>
    </div>
    
    <!-- Tabs -->
    <div style="display:flex; gap:6px; margin-bottom:24px; background:var(--blanco); padding:6px; border-radius:30px; box-shadow:var(--sombra-1); flex-wrap:wrap;">
        <a href="?tab=perfil" class="perfil-tab <?= $tab === 'perfil' ? 'active' : '' ?>" style="padding:12px 20px; border-radius:24px; text-decoration:none; font-weight:600; font-size:13px; transition:all 0.3s; background:<?= $tab === 'perfil' ? 'var(--verde-oscuro)' : 'transparent' ?>; color:<?= $tab === 'perfil' ? 'white' : 'var(--texto-2)' ?>;">
            <i class="fa-solid fa-id-card"></i> Mis datos
        </a>
        <a href="?tab=pedidos" class="perfil-tab <?= $tab === 'pedidos' ? 'active' : '' ?>" style="padding:12px 20px; border-radius:24px; text-decoration:none; font-weight:600; font-size:13px; transition:all 0.3s; background:<?= $tab === 'pedidos' ? 'var(--verde-oscuro)' : 'transparent' ?>; color:<?= $tab === 'pedidos' ? 'white' : 'var(--texto-2)' ?>;">
            <i class="fa-solid fa-box"></i> Mis pedidos
        </a>
        <a href="?tab=seguridad" class="perfil-tab <?= $tab === 'seguridad' ? 'active' : '' ?>" style="padding:12px 20px; border-radius:24px; text-decoration:none; font-weight:600; font-size:13px; transition:all 0.3s; background:<?= $tab === 'seguridad' ? 'var(--verde-oscuro)' : 'transparent' ?>; color:<?= $tab === 'seguridad' ? 'white' : 'var(--texto-2)' ?>;">
            <i class="fa-solid fa-lock"></i> Seguridad
        </a>
        <a href="<?= SITE_URL ?>/pages/logout.php" style="padding:12px 20px; border-radius:24px; text-decoration:none; font-weight:600; font-size:13px; transition:all 0.3s; background:transparent; color:var(--rojo); margin-left:auto;">
            <i class="fa-solid fa-right-from-bracket"></i> Cerrar sesión
        </a>
    </div>
    
    <!-- Contenido Tabs -->
    <?php if ($tab === 'perfil'): ?>
        <div style="background:var(--blanco); padding:30px; border-radius:var(--radius-lg); box-shadow:var(--sombra-1);">
            <h2 style="font-size:22px; color:var(--verde-oscuro); margin-bottom:20px;"><i class="fa-solid fa-id-card"></i> Mis datos personales</h2>
            <form method="POST" data-validate>
                <input type="hidden" name="action" value="actualizar_perfil">
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                    <div>
                        <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Nombre completo *</label>
                        <input type="text" name="nombre" required value="<?= htmlspecialchars($cliente['nombre']) ?>" 
                               style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); font-size:14px; outline:none;">
                    </div>
                    <div>
                        <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Celular *</label>
                        <input type="tel" name="celular" required value="<?= htmlspecialchars($cliente['celular']) ?>" maxlength="9"
                               style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); font-size:14px; outline:none;">
                    </div>
                    <div>
                        <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Email *</label>
                        <input type="email" name="email" required value="<?= htmlspecialchars($cliente['email']) ?>"
                               style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); font-size:14px; outline:none;">
                    </div>
                    <div>
                        <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Referencia</label>
                        <input type="text" name="referencia" value="<?= htmlspecialchars($cliente['referencia'] ?? '') ?>" placeholder="Ej. Frente al parque"
                               style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); font-size:14px; outline:none;">
                    </div>
                    <div style="grid-column:1 / -1;">
                        <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Dirección de entrega</label>
                        <input type="text" name="direccion" value="<?= htmlspecialchars($cliente['direccion'] ?? '') ?>" placeholder="Av. / Jr. / Calle, número"
                               style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); font-size:14px; outline:none;">
                    </div>
                </div>
                <button type="submit" class="btn-loader" style="margin-top:20px; background:var(--verde-oscuro); color:white; padding:12px 28px; border-radius:var(--radius-sm); font-weight:600; border:none; cursor:pointer;">
                    <span class="btn-text"><i class="fa-solid fa-save"></i> Guardar cambios</span>
                    <span class="btn-loading" style="display:none;"><i class="fa-solid fa-spinner fa-spin"></i> Guardando...</span>
                </button>
            </form>
        </div>
        
    <?php elseif ($tab === 'pedidos'): ?>
        <div style="background:var(--blanco); padding:30px; border-radius:var(--radius-lg); box-shadow:var(--sombra-1);">
            <h2 style="font-size:22px; color:var(--verde-oscuro); margin-bottom:20px;"><i class="fa-solid fa-box"></i> Historial de pedidos</h2>
            
            <?php if (empty($pedidos)): ?>
                <div style="text-align:center; padding:40px 20px;">
                    <i class="fa-solid fa-box-open" style="font-size:60px; color:var(--gris-3); margin-bottom:16px;"></i>
                    <h3 style="color:var(--texto); margin-bottom:8px;">Aún no tienes pedidos</h3>
                    <p style="color:var(--gris-texto); margin-bottom:20px;">Cuando realices tu primer pedido aparecerá aquí.</p>
                    <a href="<?= SITE_URL ?>/pages/tienda.php" class="btn btn-primary">
                        <i class="fa-solid fa-shop"></i> Ir a la tienda
                    </a>
                </div>
            <?php else: ?>
                <div style="display:flex; flex-direction:column; gap:12px;">
                    <?php foreach ($pedidos as $p): 
                        $estado = $ESTADOS_PEDIDO[$p['estado']];
                    ?>
                        <div style="border:1px solid var(--gris-2); border-radius:var(--radius-md); padding:18px; transition:all 0.2s;" 
                             onmouseover="this.style.borderColor='var(--verde-claro)'; this.style.boxShadow='var(--sombra-1)'"
                             onmouseout="this.style.borderColor='var(--gris-2)'; this.style.boxShadow='none'">
                            <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px;">
                                <div>
                                    <strong style="font-size:16px; color:var(--verde-oscuro);">#<?= SITE_PREFIX ?>-<?= str_pad($p['id'], 5, '0', STR_PAD_LEFT) ?></strong>
                                    <span style="margin-left:10px; font-size:13px; color:var(--gris-texto);"><?= date('d/m/Y H:i', strtotime($p['fecha_pedido'])) ?></span>
                                </div>
                                <div style="display:flex; gap:10px; align-items:center;">
                                    <span class="badge-status <?= $estado['color'] ?>" style="padding:4px 10px; border-radius:12px; font-size:11px; font-weight:600;">
                                        <?= $estado['label'] ?>
                                    </span>
                                    <strong style="font-size:18px; color:var(--verde-oscuro);"><?= formatPrecio($p['total']) ?></strong>
                                </div>
                            </div>
                            <div style="margin-top:10px; font-size:13px; color:var(--gris-texto);">
                                <i class="fa-solid fa-truck"></i> <?= htmlspecialchars($p['direccion']) ?> 
                                · <i class="fa-solid fa-wallet"></i> <?= ucfirst($p['metodo_pago']) ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        
    <?php elseif ($tab === 'seguridad'): ?>
        <div style="background:var(--blanco); padding:30px; border-radius:var(--radius-lg); box-shadow:var(--sombra-1); max-width:540px;">
            <h2 style="font-size:22px; color:var(--verde-oscuro); margin-bottom:20px;"><i class="fa-solid fa-shield-halved"></i> Cambiar contraseña</h2>
            <form method="POST" data-validate>
                <input type="hidden" name="action" value="cambiar_password">
                <div style="margin-bottom:16px;">
                    <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Contraseña actual *</label>
                    <input type="password" name="password_actual" required
                           style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); font-size:14px; outline:none;">
                </div>
                <div style="margin-bottom:16px;">
                    <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Nueva contraseña *</label>
                    <input type="password" name="password_nueva" required id="newPwd" oninput="checkStrength(this.value)"
                           style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); font-size:14px; outline:none;">
                    <div id="strengthBar" style="margin-top:6px; display:flex; gap:3px;">
                        <div style="flex:1; height:3px; background:var(--gris-2); border-radius:2px;"></div>
                        <div style="flex:1; height:3px; background:var(--gris-2); border-radius:2px;"></div>
                        <div style="flex:1; height:3px; background:var(--gris-2); border-radius:2px;"></div>
                        <div style="flex:1; height:3px; background:var(--gris-2); border-radius:2px;"></div>
                    </div>
                </div>
                <div style="margin-bottom:24px;">
                    <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Confirmar nueva contraseña *</label>
                    <input type="password" name="password_confirmar" required
                           style="width:100%; padding:12px 14px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); font-size:14px; outline:none;">
                </div>
                <button type="submit" class="btn-loader" style="background:var(--verde-oscuro); color:white; padding:12px 28px; border-radius:var(--radius-sm); font-weight:600; border:none; cursor:pointer;">
                    <span class="btn-text"><i class="fa-solid fa-key"></i> Actualizar contraseña</span>
                    <span class="btn-loading" style="display:none;"><i class="fa-solid fa-spinner fa-spin"></i> Actualizando...</span>
                </button>
            </form>
        </div>
    <?php endif; ?>
</section>

<script>
function checkStrength(pwd) {
    const bars = document.querySelectorAll('#strengthBar > div');
    let score = 0;
    if (pwd.length >= 6) score++;
    if (pwd.length >= 10) score++;
    if (/[A-Z]/.test(pwd) && /[a-z]/.test(pwd)) score++;
    if (/\d/.test(pwd) || /[^a-zA-Z0-9]/.test(pwd)) score++;
    const colors = ['#E53935', '#FB8C00', '#FFD23F', '#7BC950'];
    bars.forEach((bar, i) => {
        bar.style.background = i < score ? colors[score-1] : 'var(--gris-2)';
    });
}

document.querySelectorAll('.btn-loader').forEach(btn => {
    btn.addEventListener('click', function() {
        const form = this.closest('form');
        if (form && form.checkValidity()) {
            this.querySelector('.btn-text').style.display = 'none';
            this.querySelector('.btn-loading').style.display = 'inline';
        }
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
