<?php
/**
 * BodegaViva - Detalle del producto con reseñas
 */
if (!ob_get_level()) { ob_start(); }
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    header('Location: ' . SITE_URL . '/pages/tienda.php');
    echo '<script>window.location.href="' . SITE_URL . '/pages/tienda.php";</script>';
    exit;
}

$producto = $db->fetchOne(
    "SELECT p.*, c.nombre AS categoria_nombre,
            (SELECT AVG(calificacion) FROM resenas WHERE producto_id = p.id AND estado = 'aprobada') AS promedio_calificacion,
            (SELECT COUNT(*) FROM resenas WHERE producto_id = p.id AND estado = 'aprobada') AS total_resenas
     FROM productos p 
     INNER JOIN categorias c ON p.categoria_id = c.id 
     WHERE p.id = ?",
    ['i', $id]
);
if (!$producto) {
    http_response_code(404);
    header('Location: ' . SITE_URL . '/404.php');
    exit;
}

// Procesar nueva reseña
$errores_resena = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'nueva_resena') {
    if (!isCliente()) {
        flash('error', 'Debes iniciar sesión para dejar una reseña.');
        header('Location: ' . SITE_URL . '/pages/login.php?redirect=' . urlencode($_SERVER['REQUEST_URI']));
        echo '<script>window.location.href="' . SITE_URL . '/pages/login.php";</script>';
        exit;
    }
    $calificacion = (int)($_POST['calificacion'] ?? 5);
    $comentario = trim($_POST['comentario'] ?? '');
    $cliente = getCliente();
    
    if ($calificacion < 1 || $calificacion > 5) $errores_resena[] = 'Calificación inválida';
    if (empty($comentario)) $errores_resena[] = 'El comentario es obligatorio';
    elseif (strlen($comentario) < 10) $errores_resena[] = 'El comentario debe tener al menos 10 caracteres';
    
    // Verificar si ya reseñó
    $existe = $db->fetchOne("SELECT id FROM resenas WHERE producto_id = ? AND cliente_id = ?", ['ii', $id, $cliente['id']]);
    if ($existe) $errores_resena[] = 'Ya has reseñado este producto';
    
    if (empty($errores_resena)) {
        $db->insert(
            "INSERT INTO resenas (producto_id, cliente_id, nombre_cliente, calificacion, comentario, estado) 
             VALUES (?, ?, ?, ?, ?, 'aprobada')",
            ['iisis', $id, $cliente['id'], $cliente['nombre'], $calificacion, $comentario]
        );
        flash('success', '¡Gracias por tu reseña!');
        header('Location: ' . SITE_URL . '/pages/producto.php?id=' . $id . '#reseñas');
        echo '<script>window.location.href="' . SITE_URL . '/pages/producto.php?id=' . $id . '#reseñas";</script>';
        exit;
    }
}

// Obtener reseñas
$resenas = $db->fetchAll(
    "SELECT * FROM resenas WHERE producto_id = ? AND estado = 'aprobada' ORDER BY fecha_creacion DESC",
    ['i', $id]
);

// Productos relacionados
$relacionados = $db->fetchAll(
    "SELECT p.*, c.nombre AS categoria_nombre 
     FROM productos p 
     INNER JOIN categorias c ON p.categoria_id = c.id 
     WHERE p.categoria_id = ? AND p.id != ? AND p.estado = 1 
     ORDER BY p.vendidos DESC LIMIT 4",
    ['ii', $producto['categoria_id'], $id]
);

$pagina_activa = 'tienda';
$titulo = $producto['nombre'];
$css_extra = ['tienda.css'];
$js_extra = ['cart.js'];

include __DIR__ . '/../includes/header.php';
?>
<script>var SITE_URL_JS = '<?= SITE_URL ?>';</script>

<!-- BREADCRUMB -->
<nav class="breadcrumb">
    <div class="container">
        <ul>
            <li><a href="<?= SITE_URL ?>/index.php">Inicio</a></li>
            <li><a href="<?= SITE_URL ?>/pages/tienda.php">Tienda</a></li>
            <li><a href="<?= SITE_URL ?>/pages/categoria.php?id=<?= $producto['categoria_id'] ?>"><?= htmlspecialchars($producto['categoria_nombre']) ?></a></li>
            <li><?= htmlspecialchars($producto['nombre']) ?></li>
        </ul>
    </div>
</nav>

<!-- DETALLE PRODUCTO -->
<section class="container" style="padding:30px 0;">
    <div style="display:grid; grid-template-columns:1fr 1fr; gap:40px;">
        
        <!-- IMAGEN + GALERÍA (carrusel) -->
        <div style="position:relative;">
            <?php
            // Cargar galería de imágenes
            $imagenes_galeria = $db->fetchAll("SELECT * FROM imagenes_producto WHERE producto_id = ? ORDER BY orden ASC", ['i', $id]);
            $total_imagenes = count($imagenes_galeria);
            // Combinar imagen principal con galería
            $todas_imagenes = [];
            if (!empty($producto['imagen'])) $todas_imagenes[] = $producto['imagen'];
            foreach ($imagenes_galeria as $img) {
                if (!in_array($img['imagen'], $todas_imagenes)) $todas_imagenes[] = $img['imagen'];
            }
            ?>
            <div class="galeria-principal" id="galeriaPrincipal" style="background:var(--gris-claro); border-radius:var(--radius-lg); overflow:hidden; aspect-ratio:1; position:relative;">
                <?php foreach ($todas_imagenes as $i => $img): ?>
                    <img src="<?= htmlspecialchars(normalizarImagen($img)) ?>" alt="<?= htmlspecialchars($producto['nombre']) ?>" 
                         class="galeria-img <?= $i === 0 ? 'active' : '' ?>" data-index="<?= $i ?>"
                         style="position:absolute; inset:0; width:100%; height:100%; object-fit:cover; opacity:<?= $i === 0 ? '1' : '0' ?>; transition:opacity 0.5s;"
                         onerror="this.src='https://via.placeholder.com/500/0E5A3C/FFFFFF?text=<?= urlencode($producto['nombre']) ?>'">
                <?php endforeach; ?>
                
                <?php if ($producto['en_oferta'] && $producto['precio_anterior'] && $producto['precio_anterior'] > $producto['precio']): 
                    $desc = calcularDescuento($producto['precio'], $producto['precio_anterior']);
                ?>
                    <div style="position:absolute; top:20px; left:20px; background:var(--rojo); color:white; padding:8px 16px; border-radius:20px; font-weight:700; font-size:14px; z-index:10;">
                        -<?= $desc ?>% OFF
                    </div>
                <?php endif; ?>
                
                <?php if (count($todas_imagenes) > 1): ?>
                    <button onclick="cambiarImg(-1)" style="position:absolute; left:14px; top:50%; transform:translateY(-50%); background:rgba(255,255,255,0.9); width:44px; height:44px; border-radius:50%; border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:18px; color:var(--verde-oscuro); transition:all 0.2s; z-index:10;" onmouseover="this.style.background='var(--verde-oscuro)'; this.style.color='white';" onmouseout="this.style.background='rgba(255,255,255,0.9)'; this.style.color='var(--verde-oscuro)';">
                        <i class="fa-solid fa-chevron-left"></i>
                    </button>
                    <button onclick="cambiarImg(1)" style="position:absolute; right:14px; top:50%; transform:translateY(-50%); background:rgba(255,255,255,0.9); width:44px; height:44px; border-radius:50%; border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; font-size:18px; color:var(--verde-oscuro); transition:all 0.2s; z-index:10;" onmouseover="this.style.background='var(--verde-oscuro)'; this.style.color='white';" onmouseout="this.style.background='rgba(255,255,255,0.9)'; this.style.color='var(--verde-oscuro)';">
                        <i class="fa-solid fa-chevron-right"></i>
                    </button>
                    <div id="indicadores" style="position:absolute; bottom:14px; left:50%; transform:translateX(-50%); display:flex; gap:6px; z-index:10;">
                        <?php foreach ($todas_imagenes as $i => $img): ?>
                            <span onclick="irImg(<?= $i ?>)" class="indicador <?= $i === 0 ? 'active' : '' ?>" data-index="<?= $i ?>" style="width:10px; height:10px; border-radius:50%; background:<?= $i === 0 ? 'var(--amarillo)' : 'rgba(255,255,255,0.5)' ?>; cursor:pointer; transition:all 0.2s;"></span>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if (count($todas_imagenes) > 1): ?>
            <div style="display:flex; gap:8px; margin-top:12px; overflow-x:auto; padding-bottom:4px;">
                <?php foreach ($todas_imagenes as $i => $img): ?>
                    <img src="<?= htmlspecialchars(normalizarImagen($img)) ?>" 
                         onclick="irImg(<?= $i ?>)"
                         class="thumb-galeria <?= $i === 0 ? 'active' : '' ?>" data-index="<?= $i ?>"
                         style="width:70px; height:70px; object-fit:cover; border-radius:8px; cursor:pointer; border:2px solid <?= $i === 0 ? 'var(--verde-claro-2)' : 'transparent' ?>; transition:all 0.2s; flex-shrink:0;"
                         onmouseover="this.style.transform='scale(1.05)'"
                         onmouseout="this.style.transform='scale(1)'">
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- INFO -->
        <div>
            <span style="color:var(--verde-claro-2); font-size:13px; font-weight:600; text-transform:uppercase; letter-spacing:0.5px;">
                <?= htmlspecialchars($producto['categoria_nombre']) ?>
            </span>
            <h1 style="font-size:32px; color:var(--texto); margin:8px 0 6px; line-height:1.2;"><?= htmlspecialchars($producto['nombre']) ?></h1>
            <div style="color:var(--gris-texto); font-size:15px; margin-bottom:14px;">
                Marca: <strong style="color:var(--texto-2);"><?= htmlspecialchars($producto['marca']) ?></strong>
                · Presentación: <strong style="color:var(--texto-2);"><?= htmlspecialchars($producto['presentacion']) ?></strong>
            </div>
            
            <!-- Calificación -->
            <?php 
            $promedio = round($producto['promedio_calificacion'] ?? 0, 1);
            $total_res = $producto['total_resenas'] ?? 0;
            ?>
            <div style="display:flex; align-items:center; gap:10px; margin-bottom:20px;">
                <div style="display:flex; gap:2px;">
                    <?php for ($i = 1; $i <= 5; $i++): ?>
                        <i class="fa-solid fa-star" style="color:<?= $i <= round($promedio) ? 'var(--amarillo)' : 'var(--gris-3)' ?>; font-size:18px;"></i>
                    <?php endfor; ?>
                </div>
                <strong style="font-size:16px; color:var(--texto);"><?= $promedio > 0 ? number_format($promedio, 1) : 'Sin reseñas' ?></strong>
                <?php if ($total_res > 0): ?>
                    <a href="#reseñas" style="color:var(--verde-claro-2); font-size:13px; text-decoration:none;">
                        (<?= $total_res ?> <?= $total_res == 1 ? 'reseña' : 'reseñas' ?>)
                    </a>
                <?php endif; ?>
            </div>
            
            <!-- Precios -->
            <div style="display:flex; align-items:baseline; gap:14px; margin-bottom:20px; flex-wrap:wrap;">
                <span style="font-size:36px; font-weight:800; color:var(--verde-oscuro);"><?= formatPrecio($producto['precio']) ?></span>
                <?php if ($producto['precio_anterior'] && $producto['precio_anterior'] > $producto['precio']): ?>
                    <span style="font-size:18px; color:var(--gris-texto); text-decoration:line-through;"><?= formatPrecio($producto['precio_anterior']) ?></span>
                <?php endif; ?>
            </div>
            
            <!-- Descripción -->
            <div style="margin-bottom:24px;">
                <h3 style="font-size:16px; color:var(--verde-oscuro); margin-bottom:8px;">Descripción</h3>
                <p style="color:var(--texto-2); line-height:1.7; font-size:14px;"><?= htmlspecialchars($producto['descripcion']) ?></p>
            </div>
            
            <!-- Disponibilidad -->
            <div style="margin-bottom:24px; padding:14px; background:var(--gris-claro); border-radius:var(--radius-md);">
                <?php if ($producto['stock'] > 0): ?>
                    <i class="fa-solid fa-circle-check" style="color:var(--verde-claro-2);"></i>
                    <strong style="color:var(--verde-claro-2);">En stock</strong>
                    <span style="color:var(--gris-texto); font-size:13px;"> (<?= $producto['stock'] ?> disponibles)</span>
                <?php else: ?>
                    <i class="fa-solid fa-circle-xmark" style="color:var(--rojo);"></i>
                    <strong style="color:var(--rojo);">Agotado</strong>
                <?php endif; ?>
            </div>
            
            <!-- Acciones -->
            <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:20px;">
                <?php if ($producto['stock'] > 0): ?>
                    <button class="btn-add-cart btn btn-primary btn-lg" data-id="<?= $producto['id'] ?>" 
                            style="padding:14px 32px; font-size:15px; flex:1; min-width:200px;">
                        <i class="fa-solid fa-cart-plus"></i> Agregar al carrito
                    </button>
                <?php else: ?>
                    <button class="btn btn-lg" disabled style="background:var(--gris-texto); color:white; cursor:not-allowed; flex:1;">
                        <i class="fa-solid fa-ban"></i> Producto agotado
                    </button>
                <?php endif; ?>
                <button class="producto-fav" style="width:54px; height:54px; border:2px solid var(--gris-3); border-radius:50%; background:white; cursor:pointer;" aria-label="Favorito">
                    <i class="fa-regular fa-heart" style="font-size:18px; color:var(--gris-texto);"></i>
                </button>
            </div>
            
            <!-- Beneficios -->
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:14px; padding-top:20px; border-top:1px solid var(--gris-2);">
                <div style="display:flex; gap:10px; align-items:center;">
                    <div style="width:36px; height:36px; background:var(--gris-claro); border-radius:8px; display:flex; align-items:center; justify-content:center; color:var(--verde-claro-2);">
                        <i class="fa-solid fa-truck-fast"></i>
                    </div>
                    <div>
                        <strong style="font-size:13px; display:block;">Envío rápido</strong>
                        <span style="font-size:11px; color:var(--gris-texto);">30 minutos en Lima</span>
                    </div>
                </div>
                <div style="display:flex; gap:10px; align-items:center;">
                    <div style="width:36px; height:36px; background:var(--gris-claro); border-radius:8px; display:flex; align-items:center; justify-content:center; color:var(--verde-claro-2);">
                        <i class="fa-solid fa-shield-halved"></i>
                    </div>
                    <div>
                        <strong style="font-size:13px; display:block;">Pago seguro</strong>
                        <span style="font-size:11px; color:var(--gris-texto);">Yape, Plin, efectivo</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- RESEÑAS -->
<section class="container" style="padding:30px 0 60px;" id="reseñas">
    <h2 style="font-size:26px; color:var(--verde-oscuro); margin-bottom:24px;">
        <i class="fa-solid fa-comments"></i> Reseñas del producto (<?= count($resenas) ?>)
    </h2>
    
    <div style="display:grid; grid-template-columns:1fr 2fr; gap:30px;">
        
        <!-- Formulario nueva reseña -->
        <div>
            <div style="background:var(--blanco); padding:24px; border-radius:var(--radius-lg); box-shadow:var(--sombra-1); position:sticky; top:100px;">
                <h3 style="font-size:18px; color:var(--verde-oscuro); margin-bottom:14px;">Deja tu reseña</h3>
                
                <?php if (!empty($errores_resena)): ?>
                    <div class="alert alert-danger" style="background:rgba(229,57,53,0.1); padding:12px; border-radius:8px; border-left:3px solid var(--rojo); margin-bottom:14px; font-size:13px;">
                        <ul style="margin:0; padding-left:18px;">
                            <?php foreach ($errores_resena as $err): ?><li><?= htmlspecialchars($err) ?></li><?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                
                <?php if (isCliente()): ?>
                    <form method="POST" data-validate>
                        <input type="hidden" name="action" value="nueva_resena">
                        <div style="margin-bottom:14px;">
                            <label style="font-size:13px; font-weight:600; display:block; margin-bottom:8px;">Tu calificación</label>
                            <div style="display:flex; gap:4px;" id="starInput">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fa-solid fa-star star-input" data-value="<?= $i ?>" 
                                       style="font-size:28px; color:var(--gris-3); cursor:pointer; transition:all 0.2s;"></i>
                                <?php endfor; ?>
                            </div>
                            <input type="hidden" name="calificacion" id="calificacionInput" value="5" required>
                        </div>
                        <div style="margin-bottom:14px;">
                            <label style="font-size:13px; font-weight:600; display:block; margin-bottom:6px;">Tu comentario *</label>
                            <textarea name="comentario" required minlength="10" rows="4" 
                                      placeholder="Cuéntanos qué te pareció este producto..."
                                      style="width:100%; padding:12px; border:1px solid var(--gris-3); border-radius:var(--radius-sm); outline:none; font-size:14px; resize:vertical;"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary" style="width:100%;">
                            <i class="fa-solid fa-paper-plane"></i> Publicar reseña
                        </button>
                    </form>
                <?php else: ?>
                    <div style="text-align:center; padding:20px 0;">
                        <i class="fa-solid fa-user-lock" style="font-size:40px; color:var(--gris-3); margin-bottom:12px;"></i>
                        <p style="color:var(--gris-texto); font-size:14px; margin-bottom:16px;">Inicia sesión para dejar tu reseña</p>
                        <a href="<?= SITE_URL ?>/pages/login.php?redirect=<?= urlencode($_SERVER['REQUEST_URI']) ?>" class="btn btn-primary">
                            <i class="fa-solid fa-right-to-bracket"></i> Iniciar sesión
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Lista de reseñas -->
        <div>
            <?php if (empty($resenas)): ?>
                <div style="text-align:center; padding:40px 20px; background:var(--blanco); border-radius:var(--radius-lg);">
                    <i class="fa-solid fa-comment-dots" style="font-size:50px; color:var(--gris-3); margin-bottom:14px;"></i>
                    <h3 style="color:var(--texto); margin-bottom:8px;">Aún no hay reseñas</h3>
                    <p style="color:var(--gris-texto);">Sé el primero en compartir tu experiencia con este producto.</p>
                </div>
            <?php else: ?>
                <div style="display:flex; flex-direction:column; gap:14px;">
                    <?php foreach ($resenas as $r): ?>
                        <div style="background:var(--blanco); padding:18px; border-radius:var(--radius-md); box-shadow:var(--sombra-1);">
                            <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:10px;">
                                <div style="display:flex; gap:10px; align-items:center;">
                                    <div style="width:40px; height:40px; background:linear-gradient(135deg,var(--verde-claro),var(--verde-oscuro)); border-radius:50%; display:flex; align-items:center; justify-content:center; color:white; font-weight:700;">
                                        <?= strtoupper(substr($r['nombre_cliente'], 0, 1)) ?>
                                    </div>
                                    <div>
                                        <strong style="font-size:14px; display:block;"><?= htmlspecialchars($r['nombre_cliente']) ?></strong>
                                        <span style="font-size:11px; color:var(--gris-texto);"><?= date('d/m/Y', strtotime($r['fecha_creacion'])) ?></span>
                                    </div>
                                </div>
                                <div style="display:flex; gap:2px;">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <i class="fa-solid fa-star" style="color:<?= $i <= $r['calificacion'] ? 'var(--amarillo)' : 'var(--gris-3)' ?>; font-size:13px;"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <p style="color:var(--texto-2); font-size:14px; line-height:1.6;"><?= htmlspecialchars($r['comentario']) ?></p>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- PRODUCTOS RELACIONADOS -->
<?php if (!empty($relacionados)): ?>
<section class="section" style="background:var(--gris-claro);">
    <div class="container">
        <h2 style="font-size:26px; color:var(--verde-oscuro); margin-bottom:24px;">
            <i class="fa-solid fa-thumbs-up"></i> Productos relacionados
        </h2>
        <div class="productos-grid">
            <?php foreach ($relacionados as $p): ?>
                <?php include __DIR__ . '/../includes/_producto_card.php'; ?>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<?php endif; ?>

<script>
// Sistema de estrellas interactivo
document.querySelectorAll('.star-input').forEach(function (star) {
    star.addEventListener('click', function () {
        const value = parseInt(this.dataset.value);
        document.getElementById('calificacionInput').value = value;
        document.querySelectorAll('.star-input').forEach(function (s, i) {
            s.style.color = i < value ? 'var(--amarillo)' : 'var(--gris-3)';
            s.style.transform = i < value ? 'scale(1.1)' : 'scale(1)';
        });
    });
    star.addEventListener('mouseenter', function () {
        const value = parseInt(this.dataset.value);
        document.querySelectorAll('.star-input').forEach(function (s, i) {
            s.style.color = i < value ? 'var(--amarillo-osc)' : 'var(--gris-3)';
        });
    });
});
document.getElementById('starInput').addEventListener('mouseleave', function () {
    const value = parseInt(document.getElementById('calificacionInput').value);
    document.querySelectorAll('.star-input').forEach(function (s, i) {
        s.style.color = i < value ? 'var(--amarillo)' : 'var(--gris-3)';
        s.style.transform = 'scale(1)';
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>

// ============ CARRUSEL DE IMÁGENES ============
let imgActual = 0;
const totalImgs = document.querySelectorAll('.galeria-img').length;

function irImg(index) {
    if (index < 0) index = totalImgs - 1;
    if (index >= totalImgs) index = 0;
    
    document.querySelectorAll('.galeria-img').forEach(function(img, i) {
        img.style.opacity = i === index ? '1' : '0';
        img.classList.toggle('active', i === index);
    });
    
    document.querySelectorAll('.indicador').forEach(function(ind, i) {
        ind.style.background = i === index ? 'var(--amarillo)' : 'rgba(255,255,255,0.5)';
        ind.classList.toggle('active', i === index);
    });
    
    document.querySelectorAll('.thumb-galeria').forEach(function(thumb, i) {
        thumb.style.borderColor = i === index ? 'var(--verde-claro-2)' : 'transparent';
        thumb.classList.toggle('active', i === index);
    });
    
    imgActual = index;
}

function cambiarImg(direccion) {
    irImg(imgActual + direccion);
}

// Soporte de swipe en móvil
let touchStartX = 0;
const galeria = document.getElementById('galeriaPrincipal');
if (galeria) {
    galeria.addEventListener('touchstart', function(e) {
        touchStartX = e.touches[0].clientX;
    });
    galeria.addEventListener('touchend', function(e) {
        const touchEndX = e.changedTouches[0].clientX;
        const diff = touchStartX - touchEndX;
        if (Math.abs(diff) > 50) {
            cambiarImg(diff > 0 ? 1 : -1);
        }
    });
}

// Navegación con teclado
document.addEventListener('keydown', function(e) {
    if (e.key === 'ArrowLeft') cambiarImg(-1);
    if (e.key === 'ArrowRight') cambiarImg(1);
});
