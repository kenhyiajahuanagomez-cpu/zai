<?php
/**
 * ZAI - Página de Tienda
 * Lista todos los productos con filtros y ordenamiento
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

$pagina_activa = 'tienda';
$titulo = 'Tienda';
$css_extra = ['tienda.css'];
$js_extra = ['cart.js', 'tienda.js'];

// Búsqueda
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$cat = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;

if ($q) {
    $productos = buscarProductos($q);
    $titulo_pagina = 'Resultados para: "' . htmlspecialchars($q) . '"';
} elseif ($cat) {
    $productos = obtenerProductosPorCategoria($cat);
    $cat_info = $db->fetchOne("SELECT * FROM categorias WHERE id = ?", ['i', $cat]);
    $titulo_pagina = $cat_info ? $cat_info['nombre'] : 'Categoría';
} else {
    $productos = $db->fetchAll(
        "SELECT p.*, c.nombre AS categoria_nombre 
         FROM productos p 
         INNER JOIN categorias c ON p.categoria_id = c.id 
         WHERE p.estado = 1 
         ORDER BY p.destacado DESC, p.mas_vendido DESC, p.nombre ASC"
    );
    $titulo_pagina = 'Todos los productos';
}

$categorias = obtenerCategorias();

include __DIR__ . '/../includes/header.php';
?>
<script>var SITE_URL_JS = '<?= SITE_URL ?>';</script>

<!-- HERO TIENDA -->
<section class="page-hero">
    <div class="container">
        <h1><i class="fa-solid fa-shop"></i> Tienda <?= SITE_NAME ?></h1>
        <p>Explora nuestra amplia variedad de productos de abarrotes. Calidad, frescura y los mejores precios.</p>
    </div>
</section>

<!-- BREADCRUMB -->
<nav class="breadcrumb">
    <div class="container">
        <ul>
            <li><a href="<?= SITE_URL ?>/index.php">Inicio</a></li>
            <li>Tienda</li>
            <?php if ($q): ?><li>Busqueda: <?= htmlspecialchars($q) ?></li><?php endif; ?>
        </ul>
    </div>
</nav>

<!-- TIENDA LAYOUT -->
<section class="container" style="padding:40px 0;">
    <div class="tienda-layout">
        <!-- SIDEBAR FILTROS -->
        <aside class="filtros-sidebar">
            <div class="filtros-title">
                <i class="fa-solid fa-sliders"></i> Filtros
            </div>

            <div class="filtro-group">
                <h4>Categorías</h4>
                <div class="filtro-categoria <?= !$cat ? 'active' : '' ?>">
                    <a href="<?= SITE_URL ?>/pages/tienda.php" style="display:flex;align-items:center;gap:10px;width:100%;">
                        <i class="fa-solid fa-th"></i>
                        <span>Todas</span>
                        <span class="count"><?= count($productos) ?></span>
                    </a>
                </div>
                <?php foreach ($categorias as $c): ?>
                    <div class="filtro-categoria <?= $cat == $c['id'] ? 'active' : '' ?>">
                        <a href="<?= SITE_URL ?>/pages/categoria.php?id=<?= $c['id'] ?>" style="display:flex;align-items:center;gap:10px;width:100%;">
                            <i class="fa-solid <?= htmlspecialchars($c['icono'] ?: 'fa-tag') ?>"></i>
                            <span><?= htmlspecialchars($c['nombre']) ?></span>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>

            <div class="filtro-group">
                <h4>Rango de precio</h4>
                <form id="precioForm" class="price-range">
                    <input type="number" name="min" placeholder="Mín" min="0" step="0.5">
                    <input type="number" name="max" placeholder="Máx" min="0" step="0.5">
                    <button type="submit" class="btn btn-primary btn-sm" style="padding:6px 12px; border-radius:8px;"><i class="fa-solid fa-search"></i></button>
                </form>
            </div>

            <div class="filtro-group">
                <h4>Disponibilidad</h4>
                <label style="display:flex; align-items:center; gap:8px; padding:6px 0; cursor:pointer;">
                    <input type="checkbox" id="stockDisponible"> 
                    <span style="font-size:14px;">Solo disponibles</span>
                </label>
                <label style="display:flex; align-items:center; gap:8px; padding:6px 0; cursor:pointer;">
                    <input type="checkbox" id="soloOfertas">
                    <span style="font-size:14px;">Solo ofertas</span>
                </label>
            </div>

            <button class="btn btn-outline btn-block" onclick="limpiarFiltros()">
                <i class="fa-solid fa-rotate-left"></i> Limpiar filtros
            </button>
        </aside>

        <!-- CONTENIDO -->
        <div class="tienda-content">
            <div class="tienda-header">
                <div class="tienda-resultados">
                    Mostrando <strong><?= count($productos) ?></strong> productos
                </div>
                <div class="tienda-controls">
                    <label>Ordenar por:</label>
                    <select id="sortSelect">
                        <option value="popular">Más populares</option>
                        <option value="precio-asc">Precio: menor a mayor</option>
                        <option value="precio-desc">Precio: mayor a menor</option>
                        <option value="nombre">Nombre A-Z</option>
                    </select>
                    <div class="view-toggle">
                        <button class="active" data-view="grid" title="Vista en cuadrícula"><i class="fa-solid fa-th"></i></button>
                        <button data-view="list" title="Vista en lista"><i class="fa-solid fa-list"></i></button>
                    </div>
                </div>
            </div>

            <?php if (empty($productos)): ?>
                <div class="empty-state">
                    <i class="fa-solid fa-magnifying-glass"></i>
                    <h3>No se encontraron productos</h3>
                    <p>Prueba con otra búsqueda o explora nuestras categorías.</p>
                    <a href="<?= SITE_URL ?>/pages/tienda.php" class="btn btn-primary">
                        <i class="fa-solid fa-rotate-left"></i> Ver todos los productos
                    </a>
                </div>
            <?php else: ?>
                <div class="tienda-grid">
                    <?php foreach ($productos as $p): ?>
                        <?php include __DIR__ . '/../includes/_producto_card.php'; ?>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<script>
function limpiarFiltros() {
    window.location.href = '<?= SITE_URL ?>/pages/tienda.php';
}
// Filtros de disponibilidad
document.getElementById('stockDisponible')?.addEventListener('change', function() {
    document.querySelectorAll('.producto-card').forEach(card => {
        const stock = card.querySelector('.producto-disponibilidad');
        if (this.checked) {
            card.style.display = stock.classList.contains('agotado') ? 'none' : '';
        } else {
            card.style.display = '';
        }
    });
});
document.getElementById('soloOfertas')?.addEventListener('change', function() {
    document.querySelectorAll('.producto-card').forEach(card => {
        const oferta = card.querySelector('.badge-oferta');
        if (this.checked) {
            card.style.display = oferta ? '' : 'none';
        } else {
            card.style.display = '';
        }
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
