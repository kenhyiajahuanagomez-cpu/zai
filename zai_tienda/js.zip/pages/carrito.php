<?php
/**
 * ZAI - Carrito de Compras
 * Maneja acciones AJAX (add, update, remove) y muestra el carrito
 */
require_once __DIR__ . '/../config/config.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../includes/functions.php';

// ============ MANEJO DE ACCIONES AJAX ============
$action = $_GET['action'] ?? '';

if ($action === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $producto_id = (int)($_POST['producto_id'] ?? 0);
    $cantidad = (int)($_POST['cantidad'] ?? 1);
    if ($cantidad < 1) $cantidad = 1;

    $producto = obtenerProducto($producto_id);
    if (!$producto) {
        echo json_encode(['success' => false, 'mensaje' => 'Producto no encontrado']);
        exit;
    }
    if ($producto['stock'] <= 0) {
        echo json_encode(['success' => false, 'mensaje' => 'Producto agotado']);
        exit;
    }

    if (!isset($_SESSION['carrito'])) $_SESSION['carrito'] = [];
    if (isset($_SESSION['carrito'][$producto_id])) {
        $_SESSION['carrito'][$producto_id]['cantidad'] += $cantidad;
    } else {
        $_SESSION['carrito'][$producto_id] = [
            'id'        => $producto_id,
            'nombre'    => $producto['nombre'],
            'marca'     => $producto['marca'],
            'presentacion' => $producto['presentacion'],
            'precio'    => (float)$producto['precio'],
            'imagen'    => $producto['imagen'],
            'cantidad'  => $cantidad,
        ];
    }
    // No permitir más que stock disponible
    if ($_SESSION['carrito'][$producto_id]['cantidad'] > $producto['stock']) {
        $_SESSION['carrito'][$producto_id]['cantidad'] = $producto['stock'];
    }
    $cantidadTotal = 0;
    foreach ($_SESSION['carrito'] as $item) $cantidadTotal += $item['cantidad'];
    echo json_encode([
        'success'  => true,
        'cantidad'  => $cantidadTotal,
        'producto'  => $producto['nombre'],
        'subtotal'  => formatPrecio($_SESSION['carrito'][$producto_id]['precio'] * $_SESSION['carrito'][$producto_id]['cantidad']),
    ]);
    exit;
}

if ($action === 'add_combo' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $nombre = $_POST['nombre'] ?? 'Combo';
    $precio = (float)($_POST['precio'] ?? 0);
    $combo_id = 'combo_' . slug($nombre);
    if (!isset($_SESSION['carrito'])) $_SESSION['carrito'] = [];
    if (isset($_SESSION['carrito'][$combo_id])) {
        $_SESSION['carrito'][$combo_id]['cantidad'] += 1;
    } else {
        $_SESSION['carrito'][$combo_id] = [
            'id'        => $combo_id,
            'nombre'    => $nombre,
            'marca'     => 'Combo ' . SITE_NAME,
            'presentacion' => 'Combo especial',
            'precio'    => $precio,
            'imagen'    => 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?w=500&q=80',
            'cantidad'  => 1,
        ];
    }
    $cantidadTotal = 0;
    foreach ($_SESSION['carrito'] as $item) $cantidadTotal += $item['cantidad'];
    echo json_encode(['success' => true, 'cantidad' => $cantidadTotal]);
    exit;
}

if ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $producto_id = $_POST['producto_id'];
    $cantidad = max(1, (int)$_POST['cantidad']);
    if (isset($_SESSION['carrito'][$producto_id])) {
        $_SESSION['carrito'][$producto_id]['cantidad'] = $cantidad;
        $subtotal = $_SESSION['carrito'][$producto_id]['precio'] * $cantidad;
        $total = carritoTotal();
        $cantidadTotal = carritoCantidad();
        echo json_encode([
            'success'  => true,
            'subtotal' => formatPrecio($subtotal),
            'total'    => $total,
            'cantidad' => $cantidadTotal,
        ]);
    } else {
        echo json_encode(['success' => false, 'mensaje' => 'Producto no está en el carrito']);
    }
    exit;
}

if ($action === 'remove' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    $producto_id = $_POST['producto_id'];
    if (isset($_SESSION['carrito'][$producto_id])) {
        unset($_SESSION['carrito'][$producto_id]);
    }
    $total = carritoTotal();
    $cantidadTotal = carritoCantidad();
    echo json_encode([
        'success'  => true,
        'total'    => $total,
        'cantidad' => $cantidadTotal,
    ]);
    exit;
}

if ($action === 'clear' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    unset($_SESSION['carrito']);
    echo json_encode(['success' => true]);
    exit;
}

// ============ RENDERIZAR PÁGINA ============
$pagina_activa = 'carrito';
$titulo = 'Carrito de Compras';
$css_extra = ['carrito.css'];
$js_extra = ['cart.js'];

$carrito = $_SESSION['carrito'] ?? [];
$total = carritoTotal();

include __DIR__ . '/../includes/header.php';
?>
<script>var SITE_URL_JS = '<?= SITE_URL ?>';</script>

<!-- BREADCRUMB -->
<nav class="breadcrumb">
    <div class="container">
        <ul>
            <li><a href="<?= SITE_URL ?>/index.php">Inicio</a></li>
            <li>Carrito</li>
        </ul>
    </div>
</nav>

<section class="carrito-page">
    <div class="container">
        <h1 style="font-size:30px; color:var(--verde-oscuro); margin-bottom:24px;">
            <i class="fa-solid fa-cart-shopping"></i> Tu Carrito de Compras
        </h1>

        <?php if (empty($carrito)): ?>
            <!-- CARRITO VACÍO -->
            <div class="carrito-vacio">
                <div class="icon"><i class="fa-solid fa-cart-shopping"></i></div>
                <h2>Tu carrito está vacío</h2>
                <p>Parece que aún no has agregado productos. ¡Explora nuestra tienda y encuentra lo que necesitas!</p>
                <div style="display:flex; gap:10px; justify-content:center; flex-wrap:wrap;">
                    <a href="<?= SITE_URL ?>/pages/tienda.php" class="btn btn-primary btn-lg">
                        <i class="fa-solid fa-shop"></i> Ir a la tienda
                    </a>
                    <a href="<?= SITE_URL ?>/pages/ofertas.php" class="btn btn-outline btn-lg">
                        <i class="fa-solid fa-tags"></i> Ver ofertas
                    </a>
                </div>
            </div>
        <?php else: ?>
            <div class="carrito-layout">
                <!-- ITEMS -->
                <div class="carrito-items">
                    <div class="carrito-header">
                        <div>Producto</div>
                        <div>Precio</div>
                        <div>Cantidad</div>
                        <div>Subtotal</div>
                        <div></div>
                    </div>
                    <?php foreach ($carrito as $item): ?>
                        <div class="carrito-item" data-id="<?= htmlspecialchars($item['id']) ?>">
                            <div class="carrito-item-img">
                                <div class="img">
                                    <img src="<?= htmlspecialchars(normalizarImagen($item['imagen'])) ?>" alt="<?= htmlspecialchars($item['nombre']) ?>"
                                         onerror="this.src='https://via.placeholder.com/100x100/0E5A3C/FFFFFF?text=BV'">
                                </div>
                                <div class="info">
                                    <h4><?= htmlspecialchars($item['nombre']) ?></h4>
                                    <p><?= htmlspecialchars($item['marca']) ?> · <?= htmlspecialchars($item['presentacion']) ?></p>
                                </div>
                            </div>
                            <div class="carrito-item-precio"><?= formatPrecio($item['precio']) ?></div>
                            <div>
                                <div class="cantidad-control">
                                    <button class="qty-btn" data-action="minus" data-id="<?= htmlspecialchars($item['id']) ?>">−</button>
                                    <input type="number" class="qty-input" data-id="<?= htmlspecialchars($item['id']) ?>" value="<?= $item['cantidad'] ?>" min="1" readonly>
                                    <button class="qty-btn" data-action="plus" data-id="<?= htmlspecialchars($item['id']) ?>">+</button>
                                </div>
                            </div>
                            <div class="carrito-item-subtotal item-subtotal" data-id="<?= htmlspecialchars($item['id']) ?>">
                                <?= formatPrecio($item['precio'] * $item['cantidad']) ?>
                            </div>
                            <button class="carrito-item-eliminar btn-remove" data-id="<?= htmlspecialchars($item['id']) ?>" aria-label="Eliminar">
                                <i class="fa-solid fa-trash"></i>
                            </button>
                        </div>
                    <?php endforeach; ?>

                    <div class="carrito-acciones" style="margin-top:20px;">
                        <a href="<?= SITE_URL ?>/pages/tienda.php" class="btn btn-outline">
                            <i class="fa-solid fa-arrow-left"></i> Continuar comprando
                        </a>
                        <button class="btn btn-outline" onclick="limpiarCarrito()">
                            <i class="fa-solid fa-trash"></i> Vaciar carrito
                        </button>
                    </div>
                </div>

                <!-- RESUMEN -->
                <div class="carrito-resumen">
                    <h3><i class="fa-solid fa-receipt"></i> Resumen del pedido</h3>

                    <div class="cupon-input">
                        <input type="text" placeholder="Código de cupón">
                        <button onclick="aplicarCupon()">Aplicar</button>
                    </div>

                    <div class="resumen-linea">
                        <span>Subtotal</span>
                        <span class="cart-total-amount"><?= formatPrecio($total) ?></span>
                    </div>
                    <div class="resumen-linea">
                        <span>Envío</span>
                        <span style="color:var(--verde-claro-2); font-weight:600;">Gratis</span>
                    </div>
                    <div class="resumen-linea">
                        <span>Descuento</span>
                        <span>S/ 0.00</span>
                    </div>
                    <div class="resumen-total">
                        <span>Total</span>
                        <span class="total-monto cart-total-amount"><?= formatPrecio($total) ?></span>
                    </div>

                    <a href="<?= SITE_URL ?>/pages/checkout.php" class="btn btn-primary btn-block btn-lg" style="margin-top:20px;">
                        <i class="fa-solid fa-lock"></i> Finalizar compra
                    </a>

                    <a href="https://wa.me/<?= WHATSAPP_NUMBER ?>?text=<?= urlencode('Hola ' . SITE_NAME . ', quisiera hacer un pedido de ' . count($carrito) . ' productos por un total de ' . formatPrecio($total) . '.') ?>" 
                       class="btn-whatsapp-checkout">
                        <i class="fa-brands fa-whatsapp"></i> Pedir por WhatsApp
                    </a>

                    <div style="text-align:center; margin-top:18px; font-size:12px; color:var(--gris-texto);">
                        <i class="fa-solid fa-shield-halved" style="color:var(--verde-claro-2);"></i> Pago 100% seguro<br>
                        <i class="fa-solid fa-truck-fast" style="color:var(--verde-claro-2);"></i> Entrega en 30 minutos
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<script>
function aplicarCupon() {
    const input = document.querySelector('.cupon-input input');
    if (input && input.value) {
        if (window.ZAIToast) ZAIToast('info', 'Cupón aplicado', 'Descuento procesado correctamente.');
    } else {
        if (window.ZAIToast) ZAIToast('error', 'Error', 'Ingresa un código de cupón.');
    }
}
function limpiarCarrito() {
    if (!confirm('¿Vaciar todo el carrito?')) return;
    fetch(SITE_URL_JS + '/pages/carrito.php?action=clear', { method: 'POST' })
        .then(r => r.json())
        .then(data => {
            if (data.success) window.location.reload();
        });
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>
