# 🌐 Cómo publicar BodegaViva en internet

Guía paso a paso para que tu web sea accesible públicamente desde cualquier dispositivo, manteniendo la base de datos en tu computadora.

---

## 📋 ¿Cómo funciona?

```
[Usuario en internet] → https://tu-url.ngrok.app → [Túnel ngrok] → [Tu PC] → [XAMPP]
                                                                       ↓
                                                              [Base de datos local]
```

- ✅ La **base de datos** queda en tu PC (XAMPP/MySQL)
- ✅ Cualquier persona con el enlace puede acceder
- ✅ No necesitas pagar hosting
- ✅ Funciona desde celular, tablet o PC de cualquier persona
- ⚠️ Tu PC debe estar **encendida** y con **internet** mientras quieras que esté pública
- ⚠️ XAMPP (Apache + MySQL) debe estar corriendo

---

## 🚀 OPCIÓN 1: ngrok (más simple, recomendada)

### Paso 1: Verificar XAMPP
1. Abre **XAMPP Control Panel**
2. Inicia **Apache** y **MySQL** (deben quedar en verde)
3. Verifica que la web funcione en `http://localhost/zai_tienda/`

### Paso 2: Instalar ngrok
1. Ve a **https://ngrok.com/download**
2. Descarga **ngrok para Windows** (archivo ZIP)
3. Extrae `ngrok.exe` en la carpeta `C:\xampp\htdocs\zai_tienda\`
   (o en `C:\Windows\` para usarlo desde cualquier lado)

### Paso 3: Registrarte y obtener authtoken
1. Regístrate gratis en **https://dashboard.ngrok.com/signup**
2. Ve a **https://dashboard.ngrok.com/get-started/your-authtoken**
3. Copia tu token (algo como `1abcXYZ...`)
4. Abre una terminal (CMD) y ejecuta:
   ```
   ngrok config add-authtoken TU_TOKEN_AQUI
   ```

### Paso 4: ¡Publicar!
**Opción A (con el script automático):**
- Doble clic en `publicar_web.bat` en la carpeta `zai_tienda`
- El script hace todo automáticamente

**Opción B (manual):**
1. Abre una terminal (CMD) en la carpeta `zai_tienda`
2. Ejecuta:
   ```
   ngrok http 80
   ```
3. Verás algo así:
   ```
   Forwarding   https://abc123-def456.ngrok-free.app -> http://localhost:80
   ```
4. Tu URL pública es: `https://abc123-def456.ngrok-free.app/zai_tienda/`

### Paso 5: Compartir
Comparte el enlace con quien quieras:
- 🏪 **Tienda:** `https://abc123.ngrok-free.app/zai_tienda/`
- 🔐 **Admin:** `https://abc123.ngrok-free.app/zai_tienda/admin/`

### ⚠️ Importante sobre ngrok gratuito
- La URL **cambia** cada vez que reinicias ngrok
- Para URL fija, debes pagar ngrok ($8/mes) o usar Cloudflare Tunnel (gratis)

---

## ☁️ OPCIÓN 2: Cloudflare Tunnel (URL más estable, gratis)

Cloudflare Tunnel es gratis y las URLs suelen ser más estables que ngrok.

### Paso 1: Descargar cloudflared
1. Ve a **https://github.com/cloudflare/cloudflared/releases/latest**
2. Descarga `cloudflared-windows-amd64.exe`
3. Renómbralo a `cloudflared.exe` y ponlo en `C:\xampp\htdocs\zai_tienda\`

### Paso 2: Iniciar túnel
- Doble clic en `publicar_cloudflare.bat`
- O ejecuta en terminal:
  ```
  cloudflared tunnel --url http://localhost:80
  ```
- Verás una URL como `https://random-words-xxxx.trycloudflare.com`
- Tu web pública: `https://random-words-xxxx.trycloudflare.com/zai_tienda/`

### Ventajas de Cloudflare vs ngrok:
- ✅ Más estable (no se cae tan fácil)
- ✅ Mejor rendimiento
- ✅ Gratis sin límite de tiempo
- ⚠️ URL también cambia al reiniciar (gratis)

---

## 🔒 Seguridad IMPORTANTE

Cuando publicas tu web, **cualquiera** puede acceder. Debes proteger el panel admin:

### 1. Cambiar contraseña del admin (¡OBLIGATORIO!)
1. Inicia sesión en `http://localhost/zai_tienda/admin/`
   - Email: `admin@bodegaviva.pe`
   - Password: `admin123`
2. La contraseña `admin123` es pública en el README. **¡CÁMBIALA!**
3. Ejecuta en phpMyAdmin → SQL:
   ```sql
   UPDATE usuarios 
   SET password = 'TU_NUEVO_HASH' 
   WHERE email = 'admin@bodegaviva.pe';
   ```
4. Para generar un hash nuevo, crea un archivo temporal `gen_hash.php`:
   ```php
   <?php echo password_hash('TU_NUEVA_PASSWORD', PASSWORD_DEFAULT); ?>
   ```
   Ábrelo en el navegador, copia el hash, pégalo en el SQL de arriba.

### 2. Cambiar email del admin
```sql
UPDATE usuarios SET email = 'tu_email_real@gmail.com' WHERE id = 1;
```

### 3. Desactivar mensajes de error (producción)
En `config/config.php`, cambiar:
```php
error_reporting(0);
ini_set('display_errors', 0);
```

### 4. Configurar número de WhatsApp real
En `config/config.php`:
```php
define('WHATSAPP_NUMBER', '519XXXXXXXX'); // Tu número real (51 + 9 dígitos)
define('CONTACT_PHONE', '(01) XXX-XXXX');
define('STORE_ADDRESS', 'Tu dirección real');
```

---

## ⏰ Mantener la web activa

Para que tu web siga funcionando:

1. ✅ **Tu PC debe estar encendida** (no en suspensión)
2. ✅ **XAMPP Apache + MySQL** deben estar corriendo
3. ✅ **ngrok/cloudflared** debe estar activo (la ventana negra abierta)
4. ✅ **Internet** debe estar conectado

### Tips para mantenerla activa:
- En Windows: ve a **Configuración → Sistema → Energía** y desactiva "Suspender automáticamente"
- Si se corta el internet, ngrok puede desconectarse. Solo reinícialo.
- Si reinicias tu PC, vuelve a ejecutar `publicar_web.bat`

---

## 🔄 Si la URL cambia (ngrok gratuito)

Cada vez que reinicies ngrok, la URL cambiará. Tienes 3 opciones:

### Opción A: Avisar a los usuarios
- Comparte la nueva URL cada vez que la necesites
- Útil si es para uso temporal (presentación, demo)

### Opción B: Pagar ngrok ($8/mes)
- Te dan una URL fija tipo `https://bodegaviva.ngrok.io`
- Mismo enlace siempre

### Opción C: Usar un dominio propio con Cloudflare (gratis)
1. Compra un dominio barato (Hostinger, GoDaddy, ~$10/año)
2. Configúralo en Cloudflare (gratis)
3. Crea un túnel con `cloudflared tunnel` (necesitas cuenta de Cloudflare)
4. Tu URL será `https://tudominio.com` siempre

---

## 📱 Probar desde tu celular

Para verificar que funciona:
1. Inicia ngrok (paso 4)
2. Copia la URL pública
3. Ábrela en tu celular (¡debe tener datos móviles, no WiFi de tu casa!)
4. Si carga la web, ¡funciona correctamente!

---

## 🆘 Solución de problemas

### "No puedo acceder a la URL pública"
- Verifica que Apache esté corriendo en XAMPP
- Verifica que ngrok no muestre errores
- Prueba primero acceder a `http://localhost/zai_tienda/` localmente

### "Las imágenes no se ven"
- Como ahora la URL es pública (https://...ngrok.app), las imágenes con rutas absolutas deben actualizarse
- Ejecuta en phpMyAdmin → SQL:
  ```sql
  UPDATE productos 
  SET imagen = REPLACE(imagen, 'http://localhost/zai_tienda', '') 
  WHERE imagen LIKE 'http://localhost/zai_tienda%';
  ```
  Esto convierte las URLs absolutas a relativas, y el sistema las convertirá automáticamente.

### "Error de conexión a la base de datos"
- Verifica que MySQL esté corriendo en XAMPP
- Reinicia XAMPP si es necesario

### "ngrok me pide authtoken"
- Ejecuta: `ngrok config add-authtoken TU_TOKEN`
- (El token lo obtienes en ngrok.com tras registrarte)

### "La URL de ngrok no carga la web"
- Verifica que estás accediendo a `https://TU_URL.ngrok.app/zai_tienda/`
- Nota la `/zai_tienda/` al final (es la carpeta del proyecto)

### "Se cierra el túnel cuando cierro la ventana"
- Es normal, el túnel solo está activo mientras ngrok/cloudflared esté corriendo
- Para mantenerlo activo en segundo plano, usa:
  ```
  ngrok http 80 --log=stdout > ngrok.log 2>&1 &
  ```

---

## 📊 Resumen de opciones

| Opción | Costo | URL fija | Dificultad | Recomendado para |
|---|---|---|---|---|
| **ngrok gratuito** | Gratis | No (cambia) | ⭐ Fácil | Demos rápidas |
| **ngrok pago** | $8/mes | Sí | ⭐ Fácil | Uso serio |
| **Cloudflare Tunnel** | Gratis | No (cambia) | ⭐⭐ Media | Más estable que ngrok |
| **Cloudflare + dominio** | ~$10/año | Sí | ⭐⭐⭐ Avanzada | Producción real |
| **Hosting gratuito** (Hostinger) | Gratis | Sí | ⭐⭐ Media | Pero la BD estaría en el hosting, no en tu PC |

---

## 🎯 Recomendación final

**Para empezar:** Usa **ngrok gratuito** con el script `publicar_web.bat`
- Es lo más simple
- Sirve para demostrar tu proyecto a cualquier persona
- Solo necesitas mantener tu PC encendida

**Para uso permanente:** Migrar a un hosting real (Hostinger, etc.)
- Pero ahí la BD ya no estará en tu PC
- Es la opción profesional definitiva

---

¿Dudas? ¡Revisa el código o experimenta! 🚀
