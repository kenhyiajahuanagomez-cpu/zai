@echo off
chcp 65001 >nul
title BodegaViva - Publicar Web Pública
color 0A

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║                                                              ║
echo  ║        BodegaViva - Publicador Web Público                  ║
echo  ║        Con ngrok (túnel seguro hacia internet)               ║
echo  ║                                                              ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.

:: Verificar si XAMPP está corriendo
echo [1/5] Verificando XAMPP...
tasklist /FI "IMAGENAME eq httpd.exe" 2>NUL | find /I "httpd.exe" >NUL
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  ⚠️  Apache no está corriendo. 
    echo  Abre XAMPP Control Panel e inicia Apache y MySQL.
    echo.
    pause
    exit /b 1
)
tasklist /FI "IMAGENAME eq mysqld.exe" 2>NUL | find /I "mysqld.exe" >NUL
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  ⚠️  MySQL no está corriendo.
    echo  Abre XAMPP Control Panel e inicia MySQL.
    echo.
    pause
    exit /b 1
)
echo    ✓ Apache y MySQL están corriendo.

:: Verificar si ngrok está instalado
echo.
echo [2/5] Verificando ngrok...
where ngrok >NUL 2>NUL
if %ERRORLEVEL% NEQ 0 (
    if not exist "ngrok.exe" (
        echo.
        echo  ⚠️  ngrok no está instalado.
        echo.
        echo  Para instalar ngrok:
        echo  1. Ve a https://ngrok.com/download
        echo  2. Descarga ngrok para Windows (zip)
        echo  3. Extrae ngrok.exe en esta misma carpeta
        echo     (C:\xampp\htdocs\zai_tienda\)
        echo  4. Regístrate gratis en ngrok.com y copia tu token
        echo  5. Ejecuta: ngrok config add-authtoken TU_TOKEN
        echo.
        echo  Presiona una tecla para abrir la página de descarga...
        pause >NUL
        start https://ngrok.com/download
        pause
        exit /b 1
    )
    set "NGROK_PATH=ngrok.exe"
) else (
    set "NGROK_PATH=ngrok"
)
echo    ✓ ngrok encontrado.

:: Verificar authtoken
echo.
echo [3/5] Verificando authtoken de ngrok...
%NGROK_PATH% config check >NUL 2>NUL
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  ⚠️  ngrok no tiene configurado tu authtoken.
    echo.
    echo  Para configurarlo:
    echo  1. Regístrate gratis en https://dashboard.ngrok.com/signup
    echo  2. Copia tu authtoken (https://dashboard.ngrok.com/get-started/your-authtoken)
    echo  3. Ejecuta en una terminal:
    echo     ngrok config add-authtoken TU_TOKEN_AQUI
    echo.
    echo  Presiona una tecla para abrir la página de tokens...
    pause >NUL
    start https://dashboard.ngrok.com/get-started/your-authtoken
    pause
    exit /b 1
)
echo    ✓ Authtoken configurado.

:: Iniciar ngrok
echo.
echo [4/5] Iniciando túnel público con ngrok...
echo.
echo  ══════════════════════════════════════════════════════════
echo  ¡IMPORTANTE! 
echo  • NO cierres esta ventana mientras quieras que la web esté pública
echo  • Tu PC debe estar encendida y conectada a internet
echo  • La URL pública se mostrará abajo (copia y compártela)
echo  ══════════════════════════════════════════════════════════
echo.
echo  Iniciando ngrok (esto abrirá una nueva ventana)...
echo  Busca la línea que dice "Forwarding" con una URL como:
echo     https://abc123.ngrok-free.app -> http://localhost:80
echo.
echo  Tu web pública será: https://abc123.ngrok-free.app/zai_tienda/
echo.

:: Iniciar ngrok en ventana nueva
start "ngrok - BodegaViva" cmd /k "%NGROK_PATH% http 80 --log=stdout"

:: Esperar a que ngrok esté listo
echo [5/5] Esperando a que ngrok esté listo...
timeout /t 8 /nobreak >NUL

:: Intentar obtener la URL pública via API de ngrok
echo.
echo  Obteniendo URL pública...
powershell -Command "try { $response = Invoke-RestMethod -Uri 'http://127.0.0.1:4040/api/tunnels' -Method Get -ErrorAction Stop; $tunnel = $response.tunnels[0].public_url; Write-Host ''; Write-Host '╔══════════════════════════════════════════════════════════════╗'; Write-Host '║'; Write-Host '║  🎉 ¡WEB PUBLICADA EXITOSAMENTE!'; Write-Host '║'; Write-Host ('║  URL pública: ' + $tunnel + '/zai_tienda/'); Write-Host '║'; Write-Host '║  Comparte este enlace con quien quieras.'; Write-Host '║'; Write-Host '║  Panel admin: ' + $tunnel + '/zai_tienda/admin/'); Write-Host '║'; Write-Host '╚══════════════════════════════════════════════════════════════╝'; Write-Host ''; Start-Process ($tunnel + '/zai_tienda/') } catch { Write-Host 'No se pudo obtener la URL automáticamente. Revisa la ventana de ngrok.' }"

echo.
echo  ══════════════════════════════════════════════════════════
echo  Para DETENER la publicación pública:
echo  1. Cierra la ventana negra de ngrok
echo  2. O presiona Ctrl+C en esa ventana
echo  ══════════════════════════════════════════════════════════
echo.
pause
